import io
import json
import logging
from datetime import datetime
from uuid import UUID
from fastapi import APIRouter, File, UploadFile, Header, Depends, HTTPException
from sqlmodel import Session, select
from app.db.session import get_session
from app.db.redis_client import redis_client
from app.models.schemas import Device, SensorData, Alert
from app.ml.models import vision_detector

logger = logging.getLogger("railo_os.camera")
router = APIRouter(prefix="/camera", tags=["ESP32-CAM Vision"])

@router.post("/upload")
async def upload_camera_frame(
    file: UploadFile = File(..., description="JPEG frame from ESP32-CAM"),
    device_id: str = Header(..., alias="X-Device-Id"),
    authorization: str = Header(...),
    session: Session = Depends(get_session)
):
    """
    Endpoint for ESP32-CAM to upload JPEG frames.
    Performs YOLOv8 inference (simulated) and publishes hazard detection to WebSocket stream.
    
    ESP32-CAM sends:
      Header: Authorization: Bearer <device_token>
      Header: X-Device-Id: <uuid>
      Body: multipart/form-data with file field containing JPEG bytes
    """
    # Validate auth token
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid authorization header.")
    token = authorization.split(" ")[1]

    # Look up device by ID and verify token
    device = session.exec(
        select(Device)
        .where(Device.id == UUID(device_id))
        .where(Device.token == token)
    ).first()
    if not device:
        raise HTTPException(status_code=401, detail="Invalid device credentials.")
    if device.type != "CAMERA":
        raise HTTPException(status_code=400, detail="This endpoint is only for CAMERA type devices.")

    # Read raw image bytes
    image_bytes = await file.read()
    image_size_kb = round(len(image_bytes) / 1024, 2)
    logger.info(f"Received {image_size_kb}KB frame from ESP32-CAM: {device.name}")

    # Run Vision Detection (YOLOv8 simulated inference)
    # In production: swap vision_detector.process_camera_feed with actual YOLO model
    # For now we use the existing mock detector that evaluates device metrics context
    latest_reading = session.exec(
        select(SensorData)
        .where(SensorData.device_id == device.id)
        .order_by(SensorData.timestamp.desc())
    ).first()

    # Build vision context from last reading or default to CLEAR
    vision_meta = {"hazard_detected": "CLEAR", "confidence": 1.0}
    if latest_reading and latest_reading.metrics:
        vision_meta = {
            "hazard_detected": latest_reading.metrics.get("hazard_detected", "CLEAR"),
            "confidence": latest_reading.metrics.get("confidence", 1.0)
        }

    detection_result = vision_detector.process_camera_feed(vision_meta)

    # Build metrics payload with vision results
    metrics = {
        "image_size_kb": image_size_kb,
        "fracture_detected": detection_result.get("fracture_detected", False),
        "obstacle_detected": detection_result.get("obstacle_detected", False),
        "confidence": detection_result.get("confidence", 1.0),
        "class_label": detection_result.get("class_label", "CLEAR"),
        "bounding_boxes": detection_result.get("bounding_boxes", []),
        "hazard_detected": "TRACK_FRACTURE" if detection_result.get("fracture_detected") 
                           else ("FOREIGN_OBSTACLE" if detection_result.get("obstacle_detected") else "CLEAR")
    }

    # Persist sensor reading in DB
    reading = SensorData(
        device_id=device.id,
        timestamp=datetime.utcnow(),
        metrics=metrics
    )
    session.add(reading)

    # Raise alert if hazard detected
    if metrics["fracture_detected"] or metrics["obstacle_detected"]:
        alert = Alert(
            level="EMERGENCY",
            message=f"[ESP32-CAM] Visual hazard detected by {device.name}: {metrics['class_label']} (conf: {metrics['confidence']:.2f})",
            device_id=device.id,
            resolved=False,
            created_at=datetime.utcnow()
        )
        session.add(alert)
        logger.warning(f"HAZARD DETECTED by camera {device.name}: {metrics['class_label']}")

    session.commit()

    # Publish to WebSocket stream for live dashboard update
    redis_client.publish("live_telemetry", json.dumps({
        "event": "camera_detection",
        "device_id": str(device.id),
        "device_name": device.name,
        "detection": metrics,
        "timestamp": datetime.utcnow().isoformat()
    }))

    return {
        "status": "processed",
        "device_id": str(device.id),
        "image_size_kb": image_size_kb,
        "detection": metrics
    }

@router.get("/detections/{device_id}")
def get_camera_detections(device_id: UUID, limit: int = 20, session: Session = Depends(get_session)):
    """Retrieves the last N camera detection results for a specific ESP32-CAM device."""
    readings = session.exec(
        select(SensorData)
        .where(SensorData.device_id == device_id)
        .order_by(SensorData.timestamp.desc())
        .limit(limit)
    ).all()
    return [{
        "timestamp": r.timestamp.isoformat(),
        "metrics": r.metrics
    } for r in readings]
