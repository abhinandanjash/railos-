import logging
from datetime import datetime
from uuid import UUID
from sqlmodel import Session, select
from app.db.session import engine
from app.ml.models import anomaly_predictor, vision_detector
from app.models.schemas import Device, SensorData, AgentLog, Alert

logger = logging.getLogger("railo_os.agents.safety")

class SafetyAgent:
    def __init__(self):
        self.name = "Safety Agent"

    def analyze_track_health(self, session: Session, track_id: UUID) -> dict:
        """Evaluates track health by aggregating metrics from all sensors associated with it."""
        logger.info(f"Safety Agent starting analysis for track: {track_id}")

        # 1. Fetch devices attached to this track
        devices = session.exec(select(Device).where(Device.track_id == track_id)).all()
        if not devices:
            return {
                "risk_score": 0.0,
                "confidence": 1.0,
                "severity": "GREEN",
                "explanation": "No devices registered for this track segment."
            }

        # 2. Gather latest sensor values
        vibration = 0.2
        tilt = 0.1
        temp = 25.0
        vision_meta = {"hazard_detected": "CLEAR", "confidence": 1.0}

        for dev in devices:
            # Query latest sensor reading
            reading = session.exec(
                select(SensorData)
                .where(SensorData.device_id == dev.id)
                .order_by(SensorData.timestamp.desc())
            ).first()

            if not reading:
                continue

            metrics = reading.metrics
            if dev.type == "VIBRATION":
                vibration = max(vibration, metrics.get("vibration", 0.2))
            elif dev.type == "TILT":
                tilt = max(tilt, metrics.get("tilt", 0.1))
            elif dev.type == "TEMP":
                temp = max(temp, metrics.get("temperature", 25.0))
            elif dev.type == "CAMERA" or dev.type == "ULTRASONIC":
                # Camera visual checks
                if "hazard_detected" in metrics:
                    vision_meta = {
                        "hazard_detected": metrics.get("hazard_detected"),
                        "confidence": metrics.get("confidence", 1.0)
                    }

        # 3. Call ML Predictor
        ml_prediction = anomaly_predictor.predict_risk(vibration, tilt, temp)
        vision_prediction = vision_detector.process_camera_feed(vision_meta)

        # 4. Integrate Vision results (Override risk if camera reports a physical obstruction/fracture)
        if vision_prediction.get("fracture_detected") or vision_prediction.get("obstacle_detected"):
            ml_prediction["risk_score"] = 95.0
            ml_prediction["severity"] = "EMERGENCY"
            ml_prediction["explanation"] = f"VISION ALERT: {vision_prediction['class_label']} confirmed with high confidence."

        # 5. Log agent action to Postgres
        log_entry = AgentLog(
            agent_name=self.name,
            action="TRACK_HEALTH_EVALUATION",
            detail={
                "track_id": str(track_id),
                "metrics": {"vibration": vibration, "tilt": tilt, "temperature": temp},
                "result": ml_prediction
            },
            timestamp=datetime.utcnow()
        )
        session.add(log_entry)
        session.commit()

        # 6. Raise alerts if severity exceeds warnings thresholds
        if ml_prediction["severity"] in ["RED", "EMERGENCY"]:
            alert = Alert(
                level="CRITICAL" if ml_prediction["severity"] == "RED" else "EMERGENCY",
                message=f"Critical track risk on {track_id}: {ml_prediction['explanation']}",
                resolved=False,
                created_at=datetime.utcnow()
            )
            session.add(alert)
            session.commit()

        return ml_prediction

safety_agent = SafetyAgent()
