import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        background: "var(--background)",
        foreground: "var(--foreground)",
        border: "var(--border)",
        cyber: {
          bg: "#020617", // slate-950
          card: "rgba(15, 23, 42, 0.45)", // glass overlay
          blue: "#00fff0", // bright cyber cyan
          neon: "#39ff14", // terminal green
          warning: "#ffaa00", // warning orange
          alert: "#ff003c", // emergency red
          accent: "#6366f1" // space indigo
        }
      },
      fontFamily: {
        mono: ["var(--font-roboto-mono)", "ui-monospace", "SFMono-Regular"],
        sans: ["var(--font-inter)", "sans-serif"]
      },
      animation: {
        "pulse-glow": "pulseGlow 2s cubic-bezier(0.4, 0, 0.6, 1) infinite",
        "radar-ping": "radarPing 2.5s cubic-bezier(0, 0, 0.2, 1) infinite",
        "scan-line": "scanLine 6s linear infinite",
        "emergency-flash": "emergencyFlash 1s ease-in-out infinite"
      },
      keyframes: {
        pulseGlow: {
          "0%, 100%": { opacity: "0.2", filter: "brightness(1)" },
          "50%": { opacity: "1", filter: "brightness(1.5)" }
        },
        radarPing: {
          "0%": { transform: "scale(0.8)", opacity: "0.5" },
          "100%": { transform: "scale(2.2)", opacity: "0" }
        },
        scanLine: {
          "0%": { transform: "translateY(-100%)" },
          "100%": { transform: "translateY(100%)" }
        },
        emergencyFlash: {
          "0%, 100%": { backgroundColor: "rgba(255, 0, 60, 0.05)", borderColor: "rgba(255, 0, 60, 0.3)" },
          "50%": { backgroundColor: "rgba(255, 0, 60, 0.25)", borderColor: "rgba(255, 0, 60, 0.9)", boxShadow: "0 0 15px rgba(255, 0, 60, 0.4)" }
        }
      }
    },
  },
  plugins: [],
};
export default config;
