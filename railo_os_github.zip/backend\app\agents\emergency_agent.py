import logging
import json
from datetime import datetime
from uuid import UUID
from sqlmodel import Session, select
from app.db.session import engine
from app.models.schemas import Incident, Train, Track, AgentLog, Alert
from app.agents.scheduling_agent import scheduling_agent
from app.agents.logistics_agent import logistics_agent
from app.db.redis_client import redis_client

logger = logging.getLogger("railo_os.agents.emergency")

class EmergencyAgent:
    def __init__(self):
        self.name = "Emergency Coordinator"

    def handle_incident(self, session: Session, incident_id: UUID) -> dict:
        """Coordinates responses to active emergencies by calling safety, scheduling, and logistics agents."""
        logger.info(f"Emergency Agent orchestrating containment for incident: {incident_id}")

        incident = session.get(Incident, incident_id)
        if not incident:
            return {"status": "error", "message": "Incident not found"}

        # 1. Gather incident telemetry
        track_id = incident.track_id
        train_id = incident.train_id

        checklist = [
            {"step": "1. Initialize containment protocol", "completed": True, "timestamp": datetime.utcnow().isoformat()},
            {"step": "2. Flag hazard area coordinates", "completed": True, "timestamp": datetime.utcnow().isoformat()},
            {"step": "3. Force emergency braking on affected trains", "completed": False, "timestamp": None},
            {"step": "4. Re-route scheduled rail traffic", "completed": False, "timestamp": None},
            {"step": "5. Update freight cargo logistics ETAs", "completed": False, "timestamp": None},
            {"step": "6. Dispatch maintenance response crew", "completed": False, "timestamp": None}
        ]

        # 2. Update Track status to EMERGENCY
        if track_id:
            track = session.get(Track, track_id)
            if track:
                track.status = "EMERGENCY"
                session.add(track)

        # 3. Halt Train on this track (Emergency Braking)
        halted_trains = []
        if train_id:
            train = session.get(Train, train_id)
            if train:
                train.status = "CRITICAL"
                train.speed = 0.0
                session.add(train)
                halted_trains.append(train.code)
        
        # If train_id not explicitly set, find all trains on this track
        if track_id:
            trains_on_track = session.exec(select(Train).where(Train.current_track_id == track_id)).all()
            for t in trains_on_track:
                if t.id != train_id:
                    t.status = "CRITICAL"
                    t.speed = 0.0
                    session.add(t)
                    halted_trains.append(t.code)

        checklist[2]["completed"] = True
        checklist[2]["timestamp"] = datetime.utcnow().isoformat()
        session.commit()

        # 4. Invoke Scheduling Agent to reroute other trains avoiding this track
        routing_actions = []
        all_trains = session.exec(select(Train)).all()
        for t in all_trains:
            # Reroute trains heading towards this blocked track
            if t.current_track_id == track_id and t.status != "CRITICAL":
                res = scheduling_agent.recalculate_route(session, t.id, blocked_track_id=track_id)
                routing_actions.append({
                    "train_code": t.code,
                    "action": "reroute",
                    "result": res
                })

        checklist[3]["completed"] = True
        checklist[3]["timestamp"] = datetime.utcnow().isoformat()
        session.commit()

        # 5. Invoke Logistics Agent to calculate delay cost offsets
        logistics_actions = []
        for t in all_trains:
            if t.current_track_id == track_id:
                for cargo in t.cargos:
                    res = logistics_agent.optimize_cargo_dispatch(session, cargo.id)
                    logistics_actions.append({
                        "cargo_code": cargo.code,
                        "new_eta": res.get("eta")
                    })

        checklist[4]["completed"] = True
        checklist[4]["timestamp"] = datetime.utcnow().isoformat()
        
        # Dispatch maintenance response crew
        checklist[5]["completed"] = True
        checklist[5]["timestamp"] = datetime.utcnow().isoformat()

        # 6. Save compiled Action Plan
        action_plan = {
            "containment_timestamp": datetime.utcnow().isoformat(),
            "halted_trains": halted_trains,
            "routing_adjustments": routing_actions,
            "logistics_impact": logistics_actions,
            "checklist": checklist
        }
        incident.action_plan = action_plan
        incident.status = "CONTAINED"
        session.add(incident)

        # Log agent execution details
        agent_log = AgentLog(
            agent_name=self.name,
            action="EMERGENCY_CONTAINMENT_PLAN",
            detail={
                "incident_id": str(incident_id),
                "type": incident.type,
                "containment_plan": action_plan
            },
            timestamp=datetime.utcnow()
        )
        session.add(agent_log)
        session.commit()

        # 7. Publish to Redis for live UI updates
        redis_client.publish("live_telemetry", json.dumps({
            "event": "incident_resolved_step",
            "incident_id": str(incident_id),
            "status": "CONTAINED",
            "action_plan": action_plan
        }))

        return action_plan

emergency_agent = EmergencyAgent()
