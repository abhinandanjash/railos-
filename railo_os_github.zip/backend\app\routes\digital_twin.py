from fastapi import APIRouter, Depends
from sqlmodel import Session, select
from app.db.session import get_session
from app.models.schemas import Station, Track, Train, Cargo, Incident, Alert

router = APIRouter(prefix="/digital-twin", tags=["Digital Twin Sync"])

@router.get("")
def get_digital_twin_state(session: Session = Depends(get_session)):
    """Consolidated state snapshot of entire railway network for UI rendering."""
    stations = session.exec(select(Station)).all()
    tracks = session.exec(select(Track)).all()
    trains = session.exec(select(Train)).all()
    cargos = session.exec(select(Cargo)).all()
    incidents = session.exec(select(Incident).where(Incident.status != "RESOLVED")).all()
    alerts = session.exec(select(Alert).where(Alert.resolved == False)).all()

    # Reformat tracks with station coordinate lookups for spatial layout rendering
    track_list = []
    station_lookup = {s.id: s for s in stations}

    for t in tracks:
        start_st = station_lookup.get(t.start_station_id)
        end_st = station_lookup.get(t.end_station_id)
        
        track_list.append({
            "id": str(t.id),
            "code": t.code,
            "name": t.name,
            "max_speed": t.max_speed,
            "status": t.status,
            "start_station": {
                "id": str(t.start_station_id),
                "code": start_st.code if start_st else "N/A",
                "name": start_st.name if start_st else "N/A",
                "lat": start_st.latitude if start_st else 0.0,
                "lon": start_st.longitude if start_st else 0.0
            } if start_st else None,
            "end_station": {
                "id": str(t.end_station_id),
                "code": end_st.code if end_st else "N/A",
                "name": end_st.name if end_st else "N/A",
                "lat": end_st.latitude if end_st else 0.0,
                "lon": end_st.longitude if end_st else 0.0
            } if end_st else None
        })

    return {
        "stations": [{
            "id": str(s.id),
            "code": s.code,
            "name": s.name,
            "latitude": s.latitude,
            "longitude": s.longitude,
            "platforms": s.platforms
        } for s in stations],
        "tracks": track_list,
        "trains": [{
            "id": str(t.id),
            "code": t.code,
            "name": t.name,
            "status": t.status,
            "current_track_id": str(t.current_track_id) if t.current_track_id else None,
            "current_station_id": str(t.current_station_id) if t.current_station_id else None,
            "latitude": t.latitude,
            "longitude": t.longitude,
            "speed": t.speed,
            "cargo": [{
                "id": str(c.id),
                "code": c.code,
                "description": c.description,
                "weight": c.weight,
                "destination_station_code": station_lookup.get(c.destination_station_id).code if station_lookup.get(c.destination_station_id) else "N/A",
                "eta": c.eta.isoformat() if c.eta else None
            } for c in t.cargos]
        } for t in trains],
        "cargos": [{
            "id": str(c.id),
            "code": c.code,
            "description": c.description,
            "weight": c.weight,
            "status": c.status,
            "train_code": session.get(Train, c.train_id).code if c.train_id else None,
            "destination": station_lookup.get(c.destination_station_id).code if station_lookup.get(c.destination_station_id) else "N/A",
            "eta": c.eta.isoformat() if c.eta else None
        } for c in cargos],
        "incidents": [{
            "id": str(inc.id),
            "code": inc.code,
            "type": inc.type,
            "severity": inc.severity,
            "status": inc.status,
            "description": inc.description,
            "track_code": session.get(Track, inc.track_id).code if inc.track_id else "N/A",
            "train_code": session.get(Train, inc.train_id).code if inc.train_id else "N/A",
            "action_plan": inc.action_plan,
            "created_at": inc.created_at.isoformat()
        } for inc in incidents],
        "alerts": [{
            "id": str(al.id),
            "level": al.level,
            "message": al.message,
            "created_at": al.created_at.isoformat()
        } for al in alerts]
    }
