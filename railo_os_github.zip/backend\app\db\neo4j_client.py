import logging
import networkx as nx
from neo4j import GraphDatabase
from app.core.config import settings

logger = logging.getLogger("railo_os.neo4j")

class GraphManager:
    """Manages the RailOS railway knowledge graph using Neo4j and NetworkX fallback."""
    def __init__(self):
        self.nx_graph = nx.DiGraph()
        self.driver = None
        self.connect_neo4j()

    def connect_neo4j(self):
        try:
            self.driver = GraphDatabase.driver(
                settings.NEO4J_URI,
                auth=(settings.NEO4J_USER, settings.NEO4J_PASSWORD)
            )
            # Verify connectivity
            with self.driver.session() as session:
                session.run("RETURN 1")
            logger.info("Connected to Neo4j database successfully.")
        except Exception as e:
            logger.warning(f"Neo4j connection omitted (using NetworkX fallback): {e}")
            self.driver = None

    def add_station(self, station_id: str, name: str, code: str, lat: float, lon: float, platforms: list):
        # 1. Update local NetworkX graph
        self.nx_graph.add_node(
            station_id,
            type="Station",
            name=name,
            code=code,
            lat=lat,
            lon=lon,
            platforms=platforms
        )
        for p in platforms:
            plat_node_id = f"{station_id}_platform_{p}"
            self.nx_graph.add_node(plat_node_id, type="Platform", name=f"Platform {p}")
            self.nx_graph.add_edge(station_id, plat_node_id, relationship="HAS_PLATFORM")

        # 2. Sync to Neo4j if available
        if self.driver:
            try:
                with self.driver.session() as session:
                    session.run(
                        """
                        MERGE (s:Station {id: $id})
                        SET s.name = $name, s.code = $code, s.lat = $lat, s.lon = $lon
                        WITH s
                        UNWIND $platforms AS plat
                        MERGE (p:Platform {id: $id + '_platform_' + plat})
                        SET p.name = 'Platform ' + plat
                        MERGE (s)-[:HAS_PLATFORM]->(p)
                        """,
                        id=str(station_id),
                        name=name,
                        code=code,
                        lat=lat,
                        lon=lon,
                        platforms=platforms
                    )
            except Exception as e:
                logger.error(f"Failed to write station to Neo4j: {e}")

    def add_track(self, track_id: str, code: str, start_station_id: str, end_station_id: str, max_speed: int):
        # 1. Update NetworkX
        # Note: Railway tracks are usually bidirectional, we model as two directed edges
        self.nx_graph.add_edge(
            start_station_id,
            end_station_id,
            track_id=track_id,
            code=code,
            max_speed=max_speed,
            relationship="CONNECTS_STATION",
            weight=1.0 # default weight
        )
        self.nx_graph.add_edge(
            end_station_id,
            start_station_id,
            track_id=track_id,
            code=code,
            max_speed=max_speed,
            relationship="CONNECTS_STATION",
            weight=1.0
        )

        # 2. Sync to Neo4j
        if self.driver:
            try:
                with self.driver.session() as session:
                    session.run(
                        """
                        MATCH (s1:Station {id: $s1_id})
                        MATCH (s2:Station {id: $s2_id})
                        MERGE (t:Track {id: $track_id})
                        SET t.code = $code, t.max_speed = $max_speed
                        MERGE (t)-[:CONNECTS_STATION]->(s1)
                        MERGE (t)-[:CONNECTS_STATION]->(s2)
                        """,
                        track_id=str(track_id),
                        code=code,
                        max_speed=max_speed,
                        s1_id=str(start_station_id),
                        s2_id=str(end_station_id)
                    )
            except Exception as e:
                logger.error(f"Failed to write track to Neo4j: {e}")

    def associate_train_route(self, train_id: str, route_id: str):
        if self.driver:
            try:
                with self.driver.session() as session:
                    session.run(
                        """
                        MERGE (tr:Train {id: $train_id})
                        MERGE (rt:Route {id: $route_id})
                        MERGE (tr)-[:ASSIGNED_ROUTE]->(rt)
                        """,
                        train_id=str(train_id),
                        route_id=str(route_id)
                    )
            except Exception as e:
                logger.error(f"Failed to associate train route in Neo4j: {e}")

    def associate_cargo_destination(self, cargo_id: str, dest_station_id: str):
        if self.driver:
            try:
                with self.driver.session() as session:
                    session.run(
                        """
                        MERGE (c:Cargo {id: $cargo_id})
                        MERGE (s:Station {id: $dest_id})
                        MERGE (c)-[:DESTINED_FOR]->(s)
                        """,
                        cargo_id=str(cargo_id),
                        dest_id=str(dest_station_id)
                    )
            except Exception as e:
                logger.error(f"Failed to associate cargo destination in Neo4j: {e}")

    def find_shortest_path(self, start_station_id: str, end_station_id: str):
        """Calculates optimal railway routes using Dijkstra pathfinding on NetworkX graph topology."""
        try:
            path = nx.shortest_path(
                self.nx_graph,
                source=str(start_station_id),
                target=str(end_station_id),
                weight="weight"
            )
            return path
        except nx.NetworkXNoPath:
            return []
        except Exception as e:
            logger.error(f"Pathfinding error: {e}")
            return []

    def close(self):
        if self.driver:
            self.driver.close()

graph_manager = GraphManager()
