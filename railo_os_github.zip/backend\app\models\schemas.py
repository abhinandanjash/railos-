from datetime import datetime
from typing import Optional, List, Dict, Any
from uuid import UUID, uuid4
from sqlmodel import SQLModel, Field, Relationship, Column, JSON

class User(SQLModel, table=True):
    __tablename__ = "users"
    id: UUID = Field(default_factory=uuid4, primary_key=True)
    username: str = Field(unique=True, index=True)
    hashed_password: str
    role: str = Field(default="OPERATOR") # e.g. ADMIN, DISPATCHER, OPERATOR, VIEWER
    created_at: datetime = Field(default_factory=datetime.utcnow)

class Station(SQLModel, table=True):
    __tablename__ = "stations"
    id: UUID = Field(default_factory=uuid4, primary_key=True)
    code: str = Field(unique=True, index=True)
    name: str
    latitude: float
    longitude: float
    platforms: List[str] = Field(default=[], sa_column=Column(JSON))
    
    # Relationships
    trains: List["Train"] = Relationship(back_populates="current_station")

class Track(SQLModel, table=True):
    __tablename__ = "tracks"
    id: UUID = Field(default_factory=uuid4, primary_key=True)
    code: str = Field(unique=True, index=True)
    name: str
    start_station_id: UUID = Field(foreign_key="stations.id")
    end_station_id: UUID = Field(foreign_key="stations.id")
    max_speed: int = Field(default=120)
    status: str = Field(default="GREEN") # GREEN, YELLOW, RED, EMERGENCY
    
    # Relationships
    devices: List["Device"] = Relationship(back_populates="track")
    incidents: List["Incident"] = Relationship(back_populates="track")

class Train(SQLModel, table=True):
    __tablename__ = "trains"
    id: UUID = Field(default_factory=uuid4, primary_key=True)
    code: str = Field(unique=True, index=True)
    name: str
    status: str = Field(default="OPERATIONAL") # OPERATIONAL, DELAYED, STOPPED, EMERGENCY
    current_track_id: Optional[UUID] = Field(default=None, foreign_key="tracks.id")
    current_station_id: Optional[UUID] = Field(default=None, foreign_key="stations.id")
    latitude: float
    longitude: float
    speed: float = Field(default=0.0)
    
    # Relationships
    current_station: Optional[Station] = Relationship(back_populates="trains")
    cargos: List["Cargo"] = Relationship(back_populates="train")
    incidents: List["Incident"] = Relationship(back_populates="train")

class Cargo(SQLModel, table=True):
    __tablename__ = "cargo"
    id: UUID = Field(default_factory=uuid4, primary_key=True)
    code: str = Field(unique=True, index=True)
    weight: float
    description: str
    train_id: Optional[UUID] = Field(default=None, foreign_key="trains.id")
    destination_station_id: UUID = Field(foreign_key="stations.id")
    eta: Optional[datetime] = Field(default=None)
    status: str = Field(default="IN_TRANSIT") # STAGED, IN_TRANSIT, DELIVERED
    
    # Relationships
    train: Optional[Train] = Relationship(back_populates="cargos")

class Device(SQLModel, table=True):
    __tablename__ = "devices"
    id: UUID = Field(default_factory=uuid4, primary_key=True)
    mac_address: str = Field(unique=True, index=True)
    type: str # VIBRATION, TILT, ULTRASONIC, TEMP, CAMERA
    name: str
    status: str = Field(default="ONLINE") # ONLINE, OFFLINE, FAULTY
    track_id: Optional[UUID] = Field(default=None, foreign_key="tracks.id")
    token: str = Field(unique=True)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    
    # Relationships
    track: Optional[Track] = Relationship(back_populates="devices")
    sensor_data: List["SensorData"] = Relationship(back_populates="device")
    alerts: List["Alert"] = Relationship(back_populates="device")

class SensorData(SQLModel, table=True):
    __tablename__ = "sensor_data"
    id: Optional[int] = Field(default=None, primary_key=True)
    device_id: UUID = Field(foreign_key="devices.id", index=True)
    timestamp: datetime = Field(default_factory=datetime.utcnow, index=True)
    metrics: Dict[str, Any] = Field(default={}, sa_column=Column(JSON))
    
    # Relationships
    device: Device = Relationship(back_populates="sensor_data")

class Alert(SQLModel, table=True):
    __tablename__ = "alerts"
    id: UUID = Field(default_factory=uuid4, primary_key=True)
    level: str = Field(default="INFO") # INFO, WARNING, CRITICAL, EMERGENCY
    message: str
    device_id: Optional[UUID] = Field(default=None, foreign_key="devices.id")
    resolved: bool = Field(default=False)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    
    # Relationships
    device: Optional[Device] = Relationship(back_populates="alerts")

class Incident(SQLModel, table=True):
    __tablename__ = "incidents"
    id: UUID = Field(default_factory=uuid4, primary_key=True)
    code: str = Field(unique=True, index=True)
    type: str # OBSTACLE_DETECTED, TRACK_FRACTURE, FLOODING, DERAILMENT, SIGNAL_FAILURE
    severity: str = Field(default="MEDIUM") # LOW, MEDIUM, HIGH, CRITICAL
    train_id: Optional[UUID] = Field(default=None, foreign_key="trains.id")
    track_id: Optional[UUID] = Field(default=None, foreign_key="tracks.id")
    status: str = Field(default="OPEN") # OPEN, CONTAINED, RESOLVED
    description: str
    action_plan: Dict[str, Any] = Field(default={}, sa_column=Column(JSON))
    created_at: datetime = Field(default_factory=datetime.utcnow)
    
    # Relationships
    train: Optional[Train] = Relationship(back_populates="incidents")
    track: Optional[Track] = Relationship(back_populates="incidents")

class MaintenanceRecord(SQLModel, table=True):
    __tablename__ = "maintenance_records"
    id: UUID = Field(default_factory=uuid4, primary_key=True)
    track_id: UUID = Field(foreign_key="tracks.id")
    date: datetime = Field(default_factory=datetime.utcnow)
    type: str # PREVENTIVE, CORRECTIVE, EMERGENCY
    details: str
    cost: float
    performed_by: str
    status: str = Field(default="SCHEDULED") # SCHEDULED, IN_PROGRESS, COMPLETED

class AgentLog(SQLModel, table=True):
    __tablename__ = "agent_logs"
    id: UUID = Field(default_factory=uuid4, primary_key=True)
    agent_name: str = Field(index=True)
    action: str
    detail: Dict[str, Any] = Field(default={}, sa_column=Column(JSON))
    timestamp: datetime = Field(default_factory=datetime.utcnow)

class SimulationEvent(SQLModel, table=True):
    __tablename__ = "simulation_events"
    id: UUID = Field(default_factory=uuid4, primary_key=True)
    type: str
    target: str # track code or train code
    severity: str
    details: Dict[str, Any] = Field(default={}, sa_column=Column(JSON))
    active: bool = Field(default=True)
    timestamp: datetime = Field(default_factory=datetime.utcnow)
