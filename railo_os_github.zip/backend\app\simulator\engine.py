import asyncio
import logging
import random
import time
from datetime import datetime
from typing import Dict, Any, List
from uuid import UUID
from sqlmodel import Session, select
from app.core.config import settings
from app.db.session import engine
from app.models.schemas import Train, Track, Station, Device, SensorData, SimulationEvent, Alert, Incident
from app.db.redis_client import redis_client
import json

logger = logging.getLogger("railo_os.simulator")

class SimulationEngine:
    def __init__(self):
        self._running = False
        self._task: Optional[asyncio.Task] = None
        self.active_scenarios: Dict[str, Any] = {} # e.g. {"TR-NDLS-CSMT": {"type": "fracture", "intensity": 0.9}}

    def start(self):
        if not self._running:
            self._running = True
            self._task = asyncio.create_task(self._run_loop())
            logger.info("Simulation engine started.")
            return True
        return False

    def stop(self):
        if self._running:
            self._running = False
            if self._task:
                self._task.cancel()
            logger.info("Simulation engine stopped.")
            return True
        return False

    def is_running(self):
        return self._running

    def trigger_anomaly(self, track_code: str, event_type: str, intensity: float):
        """Injects a real-time anomaly into a specific track coordinate."""
        self.active_scenarios[track_code] = {
            "type": event_type,
            "intensity": intensity,
            "timestamp": time.time()
        }
        logger.info(f"Anomaly injected: {event_type} on {track_code} (Intensity: {intensity})")

    def clear_anomalies(self):
        self.active_scenarios.clear()
        logger.info("All injected anomalies cleared.")

    async def _run_loop(self):
        while self._running:
            try:
                await self._step_simulation()
            except Exception as e:
                logger.error(f"Error in simulation step: {e}", exc_info=True)
            await asyncio.sleep(2.0 / settings.SIMULATION_SPEED)

    async def _step_simulation(self):
        with Session(engine) as session:
            # 1. Load active database simulation events
            events = session.exec(select(SimulationEvent).where(SimulationEvent.active == True)).all()
            self.active_scenarios = {
                e.target: {"type": e.type, "intensity": 1.0, "event_id": e.id} for e in events
            }

            # 2. Update Train Physics / Interpolation
            trains = session.exec(select(Train)).all()
            for train in trains:
                if train.status == "STOPPED" or train.status == "CRITICAL":
                    train.speed = 0.0
                    session.add(train)
                    continue

                if not train.current_track_id:
                    continue

                track = session.get(Track, train.current_track_id)
                if not track:
                    continue

                # Get start & end stations to determine trajectory
                start_st = session.get(Station, track.start_station_id)
                end_st = session.get(Station, track.end_station_id)

                if start_st and end_st:
                    # Simple linear movement back and forth along the track
                    # Update speed towards max speed
                    train.speed = min(train.speed + 5.0, float(track.max_speed))
                    
                    # Target heading: standard navigation interpolation
                    lat_diff = end_st.latitude - train.latitude
                    lon_diff = end_st.longitude - train.longitude
                    distance = (lat_diff**2 + lon_diff**2)**0.5

                    # Threshold to swap track directions or stop
                    if distance < 0.05:
                        # Reached destination platform, stop and flip
                        train.latitude = end_st.latitude
                        train.longitude = end_st.longitude
                        train.current_station_id = end_st.id
                        # Flip start/end direction of track for loop simulation
                        track.start_station_id, track.end_station_id = track.end_station_id, track.start_station_id
                        session.add(track)
                        train.speed = 0.0
                        logger.info(f"Train {train.name} arrived at station {end_st.code}.")
                    else:
                        # Step forward
                        step = (train.speed / 3600.0) * 0.1 # scaled speed step
                        train.latitude += (lat_diff / distance) * step
                        train.longitude += (lon_diff / distance) * step
                        train.current_station_id = None

                    session.add(train)

            # 3. Generate IoT Sensors Telemetry
            devices = session.exec(select(Device)).all()
            for dev in devices:
                if dev.status == "OFFLINE":
                    continue

                track_obj = session.get(Track, dev.track_id) if dev.track_id else None
                track_code = track_obj.code if track_obj else "GLOBAL"

                # Check if this track segment has an active anomaly scenario
                scenario = self.active_scenarios.get(track_code)
                is_anomalous = (scenario is not None)

                metrics = {}
                if dev.type == "VIBRATION":
                    if is_anomalous and scenario["type"] == "fracture":
                        metrics["vibration"] = random.gauss(settings.vibration_anomaly_mean, settings.vibration_anomaly_std)
                    elif is_anomalous and scenario["type"] == "flood":
                        metrics["vibration"] = random.gauss(settings.vibration_normal_mean, settings.vibration_normal_std) * 0.5
                    else:
                        # Slightly higher vibration if train is on this track
                        train_on_track = any(t.current_track_id == dev.track_id and t.speed > 0 for t in trains)
                        mult = 2.0 if train_on_track else 1.0
                        metrics["vibration"] = random.gauss(settings.vibration_normal_mean, settings.vibration_normal_std) * mult

                elif dev.type == "TILT":
                    if is_anomalous and scenario["type"] == "fracture":
                        metrics["tilt"] = random.gauss(settings.tilt_anomaly_mean, settings.tilt_anomaly_std)
                    else:
                        metrics["tilt"] = abs(random.gauss(settings.tilt_normal_mean, settings.tilt_normal_std))

                elif dev.type == "TEMP":
                    if is_anomalous and scenario["type"] == "flood":
                        metrics["temperature"] = random.gauss(settings.temperature_normal_mean - 10.0, settings.temperature_normal_std)
                    else:
                        train_on_track = any(t.current_track_id == dev.track_id for t in trains)
                        mult = 1.2 if train_on_track else 1.0
                        metrics["temperature"] = random.gauss(settings.temperature_normal_mean, settings.temperature_normal_std) * mult

                elif dev.type == "ULTRASONIC":
                    # Simulates clearance. Normal is 500cm (no obstacle).
                    if is_anomalous and scenario["type"] == "obstacle":
                        metrics["distance"] = random.uniform(5.0, 35.0) # obstacle very close!
                    else:
                        metrics["distance"] = random.uniform(450.0, 500.0)

                elif dev.type == "CAMERA":
                    if is_anomalous and scenario["type"] == "fracture":
                        metrics["hazard_detected"] = "TRACK_FRACTURE"
                        metrics["confidence"] = round(random.uniform(0.85, 0.99), 2)
                    elif is_anomalous and scenario["type"] == "obstacle":
                        metrics["hazard_detected"] = "FOREIGN_OBSTACLE"
                        metrics["confidence"] = round(random.uniform(0.90, 0.99), 2)
                    else:
                        metrics["hazard_detected"] = "CLEAR"
                        metrics["confidence"] = 1.0

                # Write sensor data to Postgres
                sensor_reading = SensorData(
                    device_id=dev.id,
                    timestamp=datetime.utcnow(),
                    metrics=metrics
                )
                session.add(sensor_reading)

                # Send live stream notification to WebSocket broker (Redis Pub/Sub)
                ws_payload = {
                    "event": "sensor_update",
                    "device_id": str(dev.id),
                    "device_name": dev.name,
                    "device_type": dev.type,
                    "track_code": track_code,
                    "metrics": metrics,
                    "timestamp": datetime.utcnow().isoformat()
                }
                redis_client.publish("live_telemetry", json.dumps(ws_payload))

            session.commit()

            # 4. Stream train positions as well
            train_positions = [{
                "id": str(t.id),
                "code": t.code,
                "name": t.name,
                "status": t.status,
                "latitude": t.latitude,
                "longitude": t.longitude,
                "speed": t.speed,
                "track_code": session.get(Track, t.current_track_id).code if t.current_track_id else "STATION"
            } for t in trains]
            
            redis_client.publish("live_telemetry", json.dumps({
                "event": "train_positions",
                "trains": train_positions,
                "timestamp": datetime.utcnow().isoformat()
            }))

# Singleton Instance
simulation_engine = SimulationEngine()
