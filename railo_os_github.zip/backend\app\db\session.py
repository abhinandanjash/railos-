import os
from sqlmodel import SQLModel, create_engine, Session
from sqlalchemy.exc import OperationalError
from app.core.config import settings

# Attempt to connect to PostgreSQL, fall back to SQLite if unavailable
try:
    engine = create_engine(
        settings.DATABASE_URL,
        echo=False,
        pool_pre_ping=True,
        connect_args={"connect_timeout": 3} # Quick timeout for fast fallback
    )
    # Test connection
    with engine.connect() as conn:
        pass
    print("Database: Connected to PostgreSQL.")
except Exception as e:
    print(f"PostgreSQL connection failed ({e}). Falling back to local SQLite.")
    sqlite_path = os.path.join(os.getcwd(), "railo_os.db")
    engine = create_engine(
        f"sqlite:///{sqlite_path}",
        echo=False,
        connect_args={"check_same_thread": False}
    )

def init_db():
    SQLModel.metadata.create_all(engine)


def get_session():
    with Session(engine) as session:
        yield session

