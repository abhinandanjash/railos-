/**
 * RailOS ESP32 Firmware - HC-SR04 Ultrasonic Obstacle Sensor Node
 * ================================================================
 * Hardware: ESP32 DevKit + HC-SR04 Ultrasonic Distance Sensor
 * 
 * Wiring:
 *   HC-SR04 VCC   → ESP32 5V (use VIN pin, not 3.3V!)
 *   HC-SR04 GND   → ESP32 GND
 *   HC-SR04 TRIG  → ESP32 GPIO 5
 *   HC-SR04 ECHO  → ESP32 GPIO 18 (use voltage divider: 1kΩ + 2kΩ to protect 3.3V pin)
 * 
 * ⚠️ NOTE: HC-SR04 ECHO outputs 5V. Use a voltage divider or logic level converter!
 *   ECHO → 1kΩ → GPIO18
 *                 ↓
 *                2kΩ → GND
 * 
 * What it detects:
 *   - Obstacles on the track (landslides, vehicles, people)
 *   - Normal clearance: > 400cm
 *   - WARNING: 50cm - 400cm
 *   - CRITICAL/EMERGENCY: < 50cm
 */

#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <EEPROM.h>

// ============================================================
// CONFIGURATION
// ============================================================
const char* WIFI_SSID     = "YOUR_WIFI_SSID";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
const char* SERVER_IP     = "192.168.1.X"; // Your PC local IP
const int   SERVER_PORT   = 8000;
const char* TRACK_CODE    = "TR-NDLS-CSMT";

const int TRIG_PIN = 5;
const int ECHO_PIN = 18;

// Alert thresholds (in centimeters)
const float CLEAR_THRESHOLD   = 400.0;  // > 400cm = clear track
const float WARNING_THRESHOLD = 100.0;  // 100-400cm = warning
const float CRITICAL_THRESHOLD = 50.0; // < 50cm = critical obstacle!

#define EEPROM_SIZE 512
#define DEVICE_ID_ADDR 0
#define TOKEN_ADDR 100

// ============================================================
// GLOBALS
// ============================================================
String deviceId = "";
String deviceToken = "";
unsigned long lastReportTime = 0;
const unsigned long REPORT_INTERVAL_MS = 1500; // 1.5s for obstacles (faster response)

// ============================================================
// SETUP
// ============================================================
void setup() {
  Serial.begin(115200);
  Serial.println("=== RailOS HC-SR04 Obstacle Node ===");

  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);

  EEPROM.begin(EEPROM_SIZE);
  connectWiFi();
  loadCredentials();
  if (deviceId == "" || deviceToken == "") {
    registerDevice();
  } else {
    Serial.println("Loaded credentials. Device ID: " + deviceId);
  }
}

// ============================================================
// MAIN LOOP
// ============================================================
void loop() {
  if (millis() - lastReportTime >= REPORT_INTERVAL_MS) {
    float distanceCm = measureDistance();

    String status = "CLEAR";
    if (distanceCm < CRITICAL_THRESHOLD) {
      status = "CRITICAL";
      Serial.println("🚨 CRITICAL: Obstacle detected at " + String(distanceCm) + "cm!");
    } else if (distanceCm < WARNING_THRESHOLD) {
      status = "WARNING";
      Serial.println("⚠️  WARNING: Object close at " + String(distanceCm) + "cm");
    } else {
      Serial.printf("[HC-SR04] Distance: %.1f cm — CLEAR\n", distanceCm);
    }

    postSensorData(distanceCm, status);
    lastReportTime = millis();
  }
}

// ============================================================
// ULTRASONIC MEASUREMENT
// ============================================================
float measureDistance() {
  // Send 10μs trigger pulse
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  // Measure echo pulse duration (timeout: 30ms = ~5m max range)
  long duration = pulseIn(ECHO_PIN, HIGH, 30000);
  if (duration == 0) return 500.0; // No echo = out of range (treat as clear)

  // Convert to centimeters: speed of sound = 343m/s = 0.0343cm/μs
  float distanceCm = (duration * 0.0343) / 2.0;
  return distanceCm;
}

// ============================================================
// WIFI CONNECTION
// ============================================================
void connectWiFi() {
  Serial.printf("Connecting to WiFi: %s\n", WIFI_SSID);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nWiFi connected! IP: " + WiFi.localIP().toString());
}

// ============================================================
// DEVICE REGISTRATION
// ============================================================
void registerDevice() {
  Serial.println("Registering with RailOS Gateway...");
  HTTPClient http;
  String url = String("http://") + SERVER_IP + ":" + SERVER_PORT + "/api/v1/sensors/register";
  String mac = WiFi.macAddress();
  mac.replace(":", "");

  String payload = "{\"mac_address\":\"" + WiFi.macAddress() + 
                   "\",\"type\":\"ULTRASONIC\",\"name\":\"ESP32-HCSR04-" + mac.substring(6) + 
                   "\",\"track_code\":\"" + TRACK_CODE + "\"}";

  http.begin(url);
  http.addHeader("Content-Type", "application/json");
  http.addHeader("Authorization", "Bearer ADMIN_JWT_TOKEN_HERE");

  int httpCode = http.POST(payload);
  if (httpCode == 201) {
    StaticJsonDocument<256> doc;
    deserializeJson(doc, http.getString());
    deviceId = doc["device_id"].as<String>();
    deviceToken = doc["token"].as<String>();
    saveCredentials();
    Serial.println("Registered! Device ID: " + deviceId);
  } else {
    Serial.printf("Registration failed. HTTP %d\n", httpCode);
  }
  http.end();
}

// ============================================================
// POST SENSOR DATA
// ============================================================
void postSensorData(float distance, String trackStatus) {
  if (WiFi.status() != WL_CONNECTED) { connectWiFi(); return; }

  HTTPClient http;
  String url = String("http://") + SERVER_IP + ":" + SERVER_PORT + "/api/v1/sensors/data";

  char payload[300];
  snprintf(payload, sizeof(payload),
    "{\"device_id\":\"%s\",\"metrics\":{\"distance\":%.2f,\"track_clearance\":\"%s\"}}",
    deviceId.c_str(), distance, trackStatus.c_str());

  http.begin(url);
  http.addHeader("Content-Type", "application/json");
  http.addHeader("Authorization", "Bearer " + deviceToken);

  int httpCode = http.POST(payload);
  Serial.printf("[%s] POST status: %d\n", httpCode == 200 ? "OK" : "ERR", httpCode);
  http.end();
}

// ============================================================
// EEPROM
// ============================================================
void saveCredentials() {
  EEPROM.writeString(DEVICE_ID_ADDR, deviceId);
  EEPROM.writeString(TOKEN_ADDR, deviceToken);
  EEPROM.commit();
}
void loadCredentials() {
  deviceId = EEPROM.readString(DEVICE_ID_ADDR);
  deviceToken = EEPROM.readString(TOKEN_ADDR);
  if (deviceId.length() < 10) deviceId = "";
  if (deviceToken.length() < 5) deviceToken = "";
}
