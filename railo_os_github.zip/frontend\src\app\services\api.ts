const API_BASE_URL = typeof window !== 'undefined' 
  ? `http://${window.location.hostname}:8000/api/v1`
  : 'http://localhost:8000/api/v1';

export const WS_BASE_URL = typeof window !== 'undefined'
  ? `ws://${window.location.hostname}:8000/api/v1/ws/live`
  : 'ws://localhost:8000/api/v1/ws/live';

export interface StationData {
  id: string;
  code: string;
  name: string;
  latitude: number;
  longitude: number;
  platforms: string[];
}

export interface TrackData {
  id: string;
  code: string;
  name: string;
  max_speed: number;
  status: 'GREEN' | 'YELLOW' | 'RED' | 'EMERGENCY';
  start_station: { code: string; name: string; lat: number; lon: number } | null;
  end_station: { code: string; name: string; lat: number; lon: number } | null;
}

export interface TrainData {
  id: string;
  code: string;
  name: string;
  status: 'OPERATIONAL' | 'DELAYED' | 'STOPPED' | 'CRITICAL';
  current_track_id: string | null;
  current_station_id: string | null;
  latitude: number;
  longitude: number;
  speed: number;
  cargo: Array<{ code: string; description: string; weight: number; destination_station_code: string; eta: string | null }>;
}

export interface CargoData {
  id: string;
  code: string;
  description: string;
  weight: number;
  status: string;
  train_code: string | null;
  destination: string;
  eta: string | null;
}

export interface IncidentData {
  id: string;
  code: string;
  type: 'OBSTACLE_DETECTED' | 'TRACK_FRACTURE' | 'FLOODING' | 'DERAILMENT';
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  status: 'OPEN' | 'CONTAINED' | 'RESOLVED';
  description: string;
  track_code: string;
  train_code: string;
  action_plan: {
    containment_timestamp: string;
    halted_trains: string[];
    routing_adjustments: any[];
    logistics_impact: any[];
    checklist: Array<{ step: string; completed: boolean; timestamp: string | null }>;
  } | null;
  created_at: string;
}

export interface AgentStatusData {
  id: string;
  name: string;
  type: string;
  model: string;
  status: 'ACTIVE' | 'IDLE';
  last_action: string;
  last_decision: any;
  last_timestamp: string | null;
}

export interface DeviceStatusData {
  id: string;
  mac_address: string;
  type: 'VIBRATION' | 'TILT' | 'ULTRASONIC' | 'TEMP' | 'CAMERA';
  name: string;
  status: 'ONLINE' | 'OFFLINE' | 'FAULTY';
  track_code: string;
  latest_metrics: Record<string, any>;
  last_ping: string | null;
}

export interface DigitalTwinState {
  stations: StationData[];
  tracks: TrackData[];
  trains: TrainData[];
  cargos: CargoData[];
  incidents: IncidentData[];
  alerts: Array<{ id: string; level: string; message: string; created_at: string }>;
}

export const api = {
  async fetchDigitalTwin(): Promise<DigitalTwinState> {
    const res = await fetch(`${API_BASE_URL}/digital-twin`);
    if (!res.ok) throw new Error('Failed to fetch Digital Twin state.');
    return res.json();
  },

  async fetchSensors(): Promise<DeviceStatusData[]> {
    const res = await fetch(`${API_BASE_URL}/sensors/status`);
    if (!res.ok) throw new Error('Failed to fetch sensors.');
    return res.json();
  },

  async fetchIncidents(): Promise<IncidentData[]> {
    const res = await fetch(`${API_BASE_URL}/incidents`);
    if (!res.ok) throw new Error('Failed to fetch incidents.');
    return res.json();
  },

  async resolveIncident(incidentId: string): Promise<any> {
    const res = await fetch(`${API_BASE_URL}/incidents/${incidentId}/resolve`, {
      method: 'POST',
    });
    if (!res.ok) throw new Error('Failed to resolve incident.');
    return res.json();
  },

  async fetchAgentStatus(): Promise<AgentStatusData[]> {
    const res = await fetch(`${API_BASE_URL}/agents/status`);
    if (!res.ok) throw new Error('Failed to fetch agent status.');
    return res.json();
  },

  async startSimulation(): Promise<any> {
    const res = await fetch(`${API_BASE_URL}/simulations/start`, { method: 'POST' });
    return res.json();
  },

  async stopSimulation(): Promise<any> {
    const res = await fetch(`${API_BASE_URL}/simulations/stop`, { method: 'POST' });
    return res.json();
  },

  async triggerAnomaly(type: string, trackCode: string): Promise<any> {
    const res = await fetch(`${API_BASE_URL}/simulations/trigger`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ type, track_code: trackCode }),
    });
    if (!res.ok) throw new Error('Failed to trigger anomaly.');
    return res.json();
  },

  async clearAnomalies(): Promise<any> {
    const res = await fetch(`${API_BASE_URL}/simulations/clear`, { method: 'POST' });
    return res.json();
  }
};
