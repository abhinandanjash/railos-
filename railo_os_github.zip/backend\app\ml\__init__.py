from .models import anomaly_predictor, vision_detector
