import logging
from datetime import datetime
from uuid import UUID
from sqlmodel import Session, select
from app.db.session import engine
from app.db.neo4j_client import graph_manager
from app.models.schemas import Train, Track, Station, AgentLog

logger = logging.getLogger("railo_os.agents.scheduling")

class SchedulingAgent:
    def __init__(self):
        self.name = "Scheduling Agent"

    def recalculate_route(self, session: Session, train_id: UUID, blocked_track_id: UUID = None) -> dict:
        """Finds the optimal path for a train. If a track is blocked, bypasses it dynamically."""
        logger.info(f"Scheduling Agent recalculating route for train: {train_id}")

        train = session.get(Train, train_id)
        if not train:
            return {"status": "error", "message": "Train not found"}

        # Determine current station and target destination stations
        # If train is on a track, use start or end station as start node
        start_station_id = train.current_station_id
        if not start_station_id and train.current_track_id:
            track = session.get(Track, train.current_track_id)
            if track:
                start_station_id = track.end_station_id # heading to end station

        if not start_station_id:
            return {"status": "error", "message": "Could not locate starting station node for pathfinding."}

        # Find destination based on cargo or predefined end nodes
        destination_station_id = None
        for cargo in train.cargos:
            destination_station_id = cargo.destination_station_id
            break

        if not destination_station_id:
            # Fallback to NDRS or HWH
            dest_station = session.exec(select(Station).where(Station.code == "CSMT")).first()
            if dest_station:
                destination_station_id = dest_station.id

        if not destination_station_id or start_station_id == destination_station_id:
            return {
                "status": "success",
                "route_path": [str(start_station_id)],
                "message": "Train already at target terminus or no routing required."
            }

        # 1. Modify NetworkX weights for blocked/unhealthy tracks
        # Fetch all tracks to build Graph
        tracks = session.exec(select(Track)).all()
        
        # Reset local NetworkX weights
        for t in tracks:
            weight = 1.0
            # If track is blocked (passed parameter or marked yellow/red/emergency)
            if blocked_track_id and t.id == blocked_track_id:
                weight = 1000.0 # set high penalty for routing
            elif t.status == "RED":
                weight = 500.0
            elif t.status == "EMERGENCY":
                weight = 10000.0 # completely blocked
            
            # Update networkx graph manager weights
            start_str = str(t.start_station_id)
            end_str = str(t.end_station_id)
            if graph_manager.nx_graph.has_edge(start_str, end_str):
                graph_manager.nx_graph[start_str][end_str]["weight"] = weight
            if graph_manager.nx_graph.has_edge(end_str, start_str):
                graph_manager.nx_graph[end_str][start_str]["weight"] = weight

        # 2. Compute Dijkstra shortest path
        path_ids = graph_manager.find_shortest_path(str(start_station_id), str(destination_station_id))

        if not path_ids:
            return {
                "status": "blocked",
                "message": "No viable bypass route exists. Advise parking train at nearest platform."
            }

        # Translate path IDs to readable Codes
        station_codes = []
        for s_id in path_ids:
            st = session.get(Station, UUID(s_id))
            if st:
                station_codes.append(st.code)

        # 3. Log routing decision
        log_entry = AgentLog(
            agent_name=self.name,
            action="ROUTE_RECALCULATION",
            detail={
                "train_id": str(train_id),
                "original_start": str(start_station_id),
                "destination": str(destination_station_id),
                "bypass_applied": blocked_track_id is not None,
                "calculated_path": station_codes
            },
            timestamp=datetime.utcnow()
        )
        session.add(log_entry)
        session.commit()

        # Update train routing logs
        return {
            "status": "success",
            "route_path": station_codes,
            "path_ids": path_ids,
            "message": f"Optimal route calculated: {' -> '.join(station_codes)}"
        }

scheduling_agent = SchedulingAgent()
