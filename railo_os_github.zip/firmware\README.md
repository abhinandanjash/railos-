# RailOS Firmware — Hardware Integration Guide

## Supported Hardware

| Sensor | Module | Pin | ESP32 GPIO | Data Sent |
|:---|:---|:---|:---|:---|
| **Vibration** | SW420 | DO | GPIO 34 | `vibration` (0.0–3.0) |
| **Tilt / IMU** | MPU6050 | SDA/SCL | GPIO 21/22 | `tilt`, `gyro_rate`, `accel_x/y/z` |
| **Obstacle** | HC-SR04 | TRIG/ECHO | GPIO 5/18 | `distance` (cm), `track_clearance` |
| **Temperature** | DS18B20 | DQ | GPIO 4 | `temperature` (°C), `thermal_status` |
| **Vision** | ESP32-CAM OV2640 | — | Built-in | JPEG frame → YOLOv8 inference |

---

## Quick Start

### Step 1 — Find your PC's local IP

```powershell
ipconfig | findstr "IPv4"
```
Look for something like `192.168.1.X`. This is your `SERVER_IP` to paste into each sketch.

### Step 2 — Install Arduino Libraries

Open **Arduino IDE → Tools → Manage Libraries** and install:

- `ArduinoJson` by Benoit Blanchon
- `MPU6050` by Electronic Cats *(for tilt sensor)*
- `OneWire` by Paul Stoffregen *(for temp sensor)*
- `DallasTemperature` by Miles Burton *(for temp sensor)*
- For ESP32-CAM: Board package `esp32` by Espressif *(board manager URL below)*

**ESP32 Board Manager URL:**
```
https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json
```

### Step 3 — Edit each sketch

Open the `.ino` file for your sensor and change:

```cpp
const char* WIFI_SSID     = "YOUR_WIFI_SSID";   // ← your WiFi name
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD"; // ← your WiFi password
const char* SERVER_IP     = "192.168.1.X";        // ← your PC's IP
const char* TRACK_CODE    = "TR-NDLS-CSMT";       // ← which track
```

Available track codes: `TR-NDLS-CSMT`, `TR-CSMT-HWH`, `TR-MAS-HWH`, `TR-SBC-CSMT`

### Step 4 — Get Admin Token for Registration

Each ESP32 registers itself ONCE on first boot. To do this, it needs an admin token.

1. Go to [http://localhost:8000/docs](http://localhost:8000/docs)
2. Click **POST /api/v1/auth/login**
3. Login with `admin@railos.ai` / `railos_admin_2025`
4. Copy the `access_token` from the response
5. Paste it into the firmware: `http.addHeader("Authorization", "Bearer <token>");`

After first registration, credentials are stored in EEPROM and survive reboots.

### Step 5 — Flash & Monitor

1. Select correct board in Arduino IDE
2. Click **Upload** (GPIO0 → GND for ESP32-CAM)
3. Open **Serial Monitor** at 115200 baud
4. Watch the sensor post data to RailOS!

---

## Network Diagram

```
[SW420 ESP32]──────┐
[MPU6050 ESP32]────┤
[HC-SR04 ESP32]────┼──── WiFi Router ──── PC (RailOS Backend :8000)
[DS18B20 ESP32]────┤                          │
[ESP32-CAM]────────┘                     Dashboard :3000
```

---

## Wiring Safety Notes

> **HC-SR04**: ECHO pin outputs 5V. Use a **voltage divider** (1kΩ + 2kΩ) or a **logic level converter** to protect the ESP32's 3.3V GPIO.

> **DS18B20**: Requires a **4.7kΩ pull-up resistor** between DQ and 3.3V — without it the sensor won't communicate.

> **ESP32-CAM**: Has no USB port. Use an **FTDI adapter** in 3.3V mode. Pull GPIO0 LOW during flash, then remove and press RST.
