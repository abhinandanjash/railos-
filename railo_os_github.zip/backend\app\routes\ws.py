import asyncio
import json
import logging
from typing import List
from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from app.db.redis_client import redis_client

logger = logging.getLogger("railo_os.ws")
router = APIRouter(prefix="/ws", tags=["WebSockets"])

class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []
        self._listener_task = None

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)
        logger.info(f"WebSocket client connected. Active connections: {len(self.active_connections)}")
        
        # Start the Redis listener loop if it's not already running
        if not self._listener_task or self._listener_task.done():
            self._listener_task = asyncio.create_task(self._redis_listener())

    def disconnect(self, websocket: WebSocket):
        self.active_connections.remove(websocket)
        logger.info(f"WebSocket client disconnected. Active connections: {len(self.active_connections)}")

    async def broadcast(self, message: dict):
        # Broadcast raw json string
        payload = json.dumps(message)
        disconnected = []
        for connection in self.active_connections:
            try:
                await connection.send_text(payload)
            except Exception as e:
                logger.error(f"WebSocket broadcast error: {e}")
                disconnected.append(connection)

        # Cleanup failed connections
        for conn in disconnected:
            self.disconnect(conn)

    async def _redis_listener(self):
        """Asynchronously listens to Redis pub/sub channel and broadcasts to clients."""
        logger.info("Starting Redis-to-WS listener worker...")
        # Since redis-py pubsub read is blocking, we run in an executor or poll with sleep.
        # However, for MockRedis, we can adapt: MockRedis has a direct callback.
        # To make it work in both contexts, we can use pubsub with run_in_executor,
        # or poll key queues. Let's do a robust, non-blocking polling loop.
        try:
            pubsub = redis_client.pubsub()
            pubsub.subscribe("live_telemetry")
            
            while True:
                # Check for messages (timeout=0.1 seconds)
                msg = pubsub.get_message(ignore_subscribe_messages=True, timeout=0.1)
                if msg:
                    data = msg["data"]
                    try:
                        parsed_data = json.loads(data)
                        await self.broadcast(parsed_data)
                    except Exception as parse_err:
                        logger.error(f"Failed to parse redis msg: {parse_err}")
                await asyncio.sleep(0.05)
        except Exception as e:
            logger.error(f"Redis WS listener crashed: {e}")
            await asyncio.sleep(2.0)
            # Restart listener
            self._listener_task = asyncio.create_task(self._redis_listener())

manager = ConnectionManager()

@router.websocket("/live")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        while True:
            # Keep connection alive, listen for client-sent heartbeats
            data = await websocket.receive_text()
            # Respond to ping
            if data == "ping":
                await websocket.send_text("pong")
    except WebSocketDisconnect:
        manager.disconnect(websocket)
    except Exception as e:
        logger.error(f"WebSocket client loop exception: {e}")
        manager.disconnect(websocket)
