import json
from datetime import datetime
from uuid import UUID, uuid4
from typing import Dict, Any, List
from fastapi import APIRouter, Depends, HTTPException, Header, status
from sqlmodel import Session, select
from app.db.session import get_session
from app.core.security import get_current_user, verify_device_token
from app.models.schemas import Device, SensorData, Track
from app.db.redis_client import redis_client
from app.agents.orchestrator import agent_orchestrator
from pydantic import BaseModel

router = APIRouter(prefix="/sensors", tags=["Sensor Gateway"])

class DeviceRegisterIn(BaseModel):
    mac_address: str
    type: str  # VIBRATION, TILT, ULTRASONIC, TEMP, CAMERA
    name: str
    track_id: Optional[UUID] = None

class SensorDataIn(BaseModel):
    device_id: UUID
    metrics: Dict[str, Any]

@router.post("/register", status_code=201)
def register_sensor(
    device_in: DeviceRegisterIn,
    session: Session = Depends(get_session),
    current_user = Depends(get_current_user)
):
    """Registers a new sensor node in the gateway. Returns unique auth token."""
    existing = session.exec(select(Device).where(Device.mac_address == device_in.mac_address)).first()
    if existing:
        raise HTTPException(status_code=400, detail="Device MAC already registered.")

    device_token = f"tok_{uuid4().hex[:16]}"
    new_device = Device(
        mac_address=device_in.mac_address,
        type=device_in.type,
        name=device_in.name,
        track_id=device_in.track_id,
        token=device_token,
        status="ONLINE"
    )
    session.add(new_device)
    session.commit()
    session.refresh(new_device)
    
    return {
        "device_id": str(new_device.id),
        "token": device_token,
        "status": new_device.status
    }

@router.post("/data")
def post_sensor_data(
    data_in: SensorDataIn,
    authorization: str = Header(..., description="Bearer token generated during registration"),
    session: Session = Depends(get_session)
):
    """Secure endpoint for physical/simulated sensors to transmit telemetry."""
    # Verify Auth Header Format
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid authorization header format.")
    
    token = authorization.split(" ")[1]
    device = verify_device_token(token, session)

    if device.id != data_in.device_id:
        raise HTTPException(status_code=403, detail="Device ID mismatch with security token.")

    # Mark device online
    device.status = "ONLINE"
    session.add(device)

    # Save telemetry metrics
    new_data = SensorData(
        device_id=device.id,
        timestamp=datetime.utcnow(),
        metrics=data_in.metrics
    )
    session.add(new_data)
    session.commit()

    # Publish telemetry event to Redis Pub/Sub for WebSockets
    track_obj = session.get(Track, device.track_id) if device.track_id else None
    track_code = track_obj.code if track_obj else "GLOBAL"

    ws_payload = {
        "event": "sensor_update",
        "device_id": str(device.id),
        "device_name": device.name,
        "device_type": device.type,
        "track_code": track_code,
        "metrics": data_in.metrics,
        "timestamp": datetime.utcnow().isoformat()
    }
    redis_client.publish("live_telemetry", json.dumps(ws_payload))

    # Trigger Autonomous Safety Evaluation
    try:
        if device.track_id:
            agent_orchestrator.run_safety_loop()
    except Exception as err:
        # Prevent telemetry posting failures if agent logic hits issues
        print(f"Safety evaluation error: {err}")

    return {"status": "queued", "alert_triggered": False}

@router.get("/status")
def get_sensors_status(session: Session = Depends(get_session)):
    """Fetches all registered devices and appends the latest telemetry metrics."""
    devices = session.exec(select(Device)).all()
    results = []
    
    for dev in devices:
        # Get latest sensor data
        latest = session.exec(
            select(SensorData)
            .where(SensorData.device_id == dev.id)
            .order_by(SensorData.timestamp.desc())
        ).first()

        track_code = "UNASSIGNED"
        if dev.track_id:
            track = session.get(Track, dev.track_id)
            if track:
                track_code = track.code

        results.append({
            "id": str(dev.id),
            "mac_address": dev.mac_address,
            "type": dev.type,
            "name": dev.name,
            "status": dev.status,
            "track_code": track_code,
            "latest_metrics": latest.metrics if latest else {},
            "last_ping": latest.timestamp.isoformat() if latest else None
        })
        
    return results
