/**
 * RailOS ESP32-CAM Firmware - Track Vision & Hazard Detection
 * ============================================================
 * Hardware: ESP32-CAM Module (AI-Thinker OV2640)
 * 
 * ⚠️ IMPORTANT: ESP32-CAM has NO USB port. Flash using:
 *   FTDI USB-to-Serial Adapter (3.3V mode)
 *   GPIO0 → GND (before flashing), remove after flash
 * 
 * Wiring (FTDI to ESP32-CAM):
 *   FTDI GND  → ESP32-CAM GND
 *   FTDI VCC  → ESP32-CAM 5V
 *   FTDI TX   → ESP32-CAM U0R (GPIO3)
 *   FTDI RX   → ESP32-CAM U0T (GPIO1)
 *   GPIO0     → GND (flash mode only!)
 * 
 * Arduino IDE Board Settings:
 *   Board: "AI Thinker ESP32-CAM"
 *   CPU Freq: 240MHz
 *   Flash Freq: 80MHz
 *   Flash Size: 4MB (32Mb)
 *   Partition Scheme: Huge App (3MB No OTA)
 * 
 * What it does:
 *   - Captures 640x480 JPEG every 3 seconds
 *   - Uploads to RailOS /api/v1/camera/upload
 *   - RailOS backend runs YOLOv8 inference for fractures/obstacles
 *   - Live results streamed to dashboard via WebSocket
 */

#include "esp_camera.h"
#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <EEPROM.h>

// ============================================================
// CAMERA PIN MAPPING — AI-Thinker ESP32-CAM
// ============================================================
#define PWDN_GPIO_NUM     32
#define RESET_GPIO_NUM    -1
#define XCLK_GPIO_NUM      0
#define SIOD_GPIO_NUM     26
#define SIOC_GPIO_NUM     27
#define Y9_GPIO_NUM       35
#define Y8_GPIO_NUM       34
#define Y7_GPIO_NUM       39
#define Y6_GPIO_NUM       36
#define Y5_GPIO_NUM       21
#define Y4_GPIO_NUM       19
#define Y3_GPIO_NUM       18
#define Y2_GPIO_NUM        5
#define VSYNC_GPIO_NUM    25
#define HREF_GPIO_NUM     23
#define PCLK_GPIO_NUM     22

// ============================================================
// CONFIGURATION
// ============================================================
const char* WIFI_SSID     = "YOUR_WIFI_SSID";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
const char* SERVER_IP     = "192.168.1.X"; // Your PC local IP
const int   SERVER_PORT   = 8000;
const char* TRACK_CODE    = "TR-NDLS-CSMT";

const unsigned long CAPTURE_INTERVAL_MS = 3000; // Capture every 3 seconds

#define EEPROM_SIZE 512
#define DEVICE_ID_ADDR 0
#define TOKEN_ADDR 100

// ============================================================
// GLOBALS
// ============================================================
String deviceId = "";
String deviceToken = "";
unsigned long lastCaptureTime = 0;
int ledPin = 4; // Built-in flash LED on ESP32-CAM

// ============================================================
// SETUP
// ============================================================
void setup() {
  Serial.begin(115200);
  Serial.println("=== RailOS ESP32-CAM Vision Node ===");

  // Flash LED indicator
  pinMode(ledPin, OUTPUT);
  digitalWrite(ledPin, LOW); // OFF initially

  // Initialize camera
  if (!initCamera()) {
    Serial.println("Camera init FAILED. Rebooting in 5s...");
    delay(5000);
    ESP.restart();
  }

  EEPROM.begin(EEPROM_SIZE);
  connectWiFi();
  loadCredentials();
  if (deviceId == "" || deviceToken == "") {
    registerDevice();
  } else {
    Serial.println("Loaded credentials. Device ID: " + deviceId);
  }
}

// ============================================================
// MAIN LOOP
// ============================================================
void loop() {
  if (millis() - lastCaptureTime >= CAPTURE_INTERVAL_MS) {
    captureAndUpload();
    lastCaptureTime = millis();
  }

  // Small delay to prevent watchdog reset
  delay(10);
}

// ============================================================
// CAMERA INITIALIZATION
// ============================================================
bool initCamera() {
  camera_config_t config;
  config.ledc_channel = LEDC_CHANNEL_0;
  config.ledc_timer   = LEDC_TIMER_0;
  config.pin_d0       = Y2_GPIO_NUM;
  config.pin_d1       = Y3_GPIO_NUM;
  config.pin_d2       = Y4_GPIO_NUM;
  config.pin_d3       = Y5_GPIO_NUM;
  config.pin_d4       = Y6_GPIO_NUM;
  config.pin_d5       = Y7_GPIO_NUM;
  config.pin_d6       = Y8_GPIO_NUM;
  config.pin_d7       = Y9_GPIO_NUM;
  config.pin_xclk     = XCLK_GPIO_NUM;
  config.pin_pclk     = PCLK_GPIO_NUM;
  config.pin_vsync    = VSYNC_GPIO_NUM;
  config.pin_href     = HREF_GPIO_NUM;
  config.pin_sscb_sda = SIOD_GPIO_NUM;
  config.pin_sscb_scl = SIOC_GPIO_NUM;
  config.pin_pwdn     = PWDN_GPIO_NUM;
  config.pin_reset    = RESET_GPIO_NUM;
  config.xclk_freq_hz = 20000000;
  config.pixel_format = PIXFORMAT_JPEG;

  // Use PSRAM for higher resolution (ESP32-CAM has 4MB PSRAM)
  if (psramFound()) {
    config.frame_size   = FRAMESIZE_VGA;    // 640x480
    config.jpeg_quality = 12;              // 0-63 lower=better quality
    config.fb_count     = 2;
  } else {
    config.frame_size   = FRAMESIZE_SVGA;  // 800x600 fallback
    config.jpeg_quality = 20;
    config.fb_count     = 1;
  }

  esp_err_t err = esp_camera_init(&config);
  if (err != ESP_OK) {
    Serial.printf("Camera init error 0x%x\n", err);
    return false;
  }

  // Optimize image settings
  sensor_t* s = esp_camera_sensor_get();
  s->set_brightness(s, 0);    // -2 to 2
  s->set_contrast(s, 0);      // -2 to 2
  s->set_saturation(s, 0);    // -2 to 2
  s->set_sharpness(s, 0);     // auto
  s->set_whitebal(s, 1);      // enable white balance
  s->set_awb_gain(s, 1);      // enable auto WB gain
  s->set_wb_mode(s, 0);       // auto WB mode
  s->set_exposure_ctrl(s, 1); // auto exposure
  s->set_aec2(s, 0);
  s->set_ae_level(s, 0);
  s->set_gain_ctrl(s, 1);     // auto gain
  s->set_agc_gain(s, 0);

  Serial.println("Camera initialized successfully.");
  return true;
}

// ============================================================
// CAPTURE AND UPLOAD
// ============================================================
void captureAndUpload() {
  // Flash LED during capture
  digitalWrite(ledPin, HIGH);

  camera_fb_t* fb = esp_camera_fb_get();
  if (!fb) {
    Serial.println("Camera capture failed!");
    digitalWrite(ledPin, LOW);
    return;
  }

  Serial.printf("[CAM] Captured %zu bytes (%dx%d)\n", fb->len, fb->width, fb->height);

  // Upload frame to RailOS gateway
  if (WiFi.status() == WL_CONNECTED) {
    uploadFrame(fb->buf, fb->len);
  } else {
    Serial.println("WiFi lost — reconnecting...");
    connectWiFi();
  }

  // Return framebuffer to driver
  esp_camera_fb_return(fb);
  digitalWrite(ledPin, LOW);
}

// ============================================================
// MULTIPART UPLOAD
// ============================================================
void uploadFrame(uint8_t* imageData, size_t imageLen) {
  HTTPClient http;
  String url = String("http://") + SERVER_IP + ":" + SERVER_PORT + "/api/v1/camera/upload";

  http.begin(url);
  http.addHeader("Authorization", "Bearer " + deviceToken);
  http.addHeader("X-Device-Id", deviceId);
  http.setTimeout(10000); // 10 second timeout

  // Build multipart form-data boundary
  String boundary = "RailOSFrameBoundary";
  String contentType = "multipart/form-data; boundary=" + boundary;
  http.addHeader("Content-Type", contentType);

  // Build multipart body header
  String bodyHeader = "--" + boundary + "\r\n";
  bodyHeader += "Content-Disposition: form-data; name=\"file\"; filename=\"frame.jpg\"\r\n";
  bodyHeader += "Content-Type: image/jpeg\r\n\r\n";
  String bodyFooter = "\r\n--" + boundary + "--\r\n";

  // Calculate total body size
  int totalLen = bodyHeader.length() + imageLen + bodyFooter.length();

  // Allocate buffer
  uint8_t* body = (uint8_t*)ps_malloc(totalLen);
  if (!body) {
    Serial.println("Memory allocation failed for upload body!");
    http.end();
    return;
  }

  // Assemble multipart body
  memcpy(body, bodyHeader.c_str(), bodyHeader.length());
  memcpy(body + bodyHeader.length(), imageData, imageLen);
  memcpy(body + bodyHeader.length() + imageLen, bodyFooter.c_str(), bodyFooter.length());

  int httpCode = http.POST(body, totalLen);
  free(body);

  if (httpCode == 200) {
    String response = http.getString();
    StaticJsonDocument<512> doc;
    deserializeJson(doc, response);
    const char* hazard = doc["detection"]["hazard_detected"] | "CLEAR";
    float confidence = doc["detection"]["confidence"] | 1.0f;
    Serial.printf("[CAM] Uploaded OK | Hazard: %s | Confidence: %.2f\n", hazard, confidence);

    if (strcmp(hazard, "CLEAR") != 0) {
      // Flash LED 3 times for detected hazard
      for (int i = 0; i < 3; i++) {
        digitalWrite(ledPin, HIGH);
        delay(100);
        digitalWrite(ledPin, LOW);
        delay(100);
      }
    }
  } else {
    Serial.printf("[ERR] Upload failed. HTTP %d\n", httpCode);
  }
  http.end();
}

// ============================================================
// WIFI CONNECTION
// ============================================================
void connectWiFi() {
  Serial.printf("Connecting to WiFi: %s\n", WIFI_SSID);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 20) {
    delay(500);
    Serial.print(".");
    attempts++;
  }
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\nWiFi connected! IP: " + WiFi.localIP().toString());
  } else {
    Serial.println("\nWiFi failed — will retry on next frame.");
  }
}

// ============================================================
// DEVICE REGISTRATION
// ============================================================
void registerDevice() {
  Serial.println("Registering ESP32-CAM with RailOS Gateway...");
  HTTPClient http;
  String url = String("http://") + SERVER_IP + ":" + SERVER_PORT + "/api/v1/sensors/register";
  String mac = WiFi.macAddress();
  mac.replace(":", "");

  String payload = "{\"mac_address\":\"" + WiFi.macAddress() + 
                   "\",\"type\":\"CAMERA\",\"name\":\"ESP32-CAM-" + mac.substring(6) + 
                   "\",\"track_code\":\"" + TRACK_CODE + "\"}";

  http.begin(url);
  http.addHeader("Content-Type", "application/json");
  http.addHeader("Authorization", "Bearer ADMIN_JWT_TOKEN_HERE");

  int httpCode = http.POST(payload);
  if (httpCode == 201) {
    StaticJsonDocument<256> doc;
    deserializeJson(doc, http.getString());
    deviceId = doc["device_id"].as<String>();
    deviceToken = doc["token"].as<String>();
    saveCredentials();
    Serial.println("Registered! Device ID: " + deviceId);
  } else {
    Serial.printf("Registration failed. HTTP %d\n", httpCode);
  }
  http.end();
}

// ============================================================
// EEPROM
// ============================================================
void saveCredentials() {
  EEPROM.writeString(DEVICE_ID_ADDR, deviceId);
  EEPROM.writeString(TOKEN_ADDR, deviceToken);
  EEPROM.commit();
}
void loadCredentials() {
  deviceId = EEPROM.readString(DEVICE_ID_ADDR);
  deviceToken = EEPROM.readString(TOKEN_ADDR);
  if (deviceId.length() < 10) deviceId = "";
  if (deviceToken.length() < 5) deviceToken = "";
}
