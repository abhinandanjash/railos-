from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import Session, select
from app.db.session import get_session
from app.models.schemas import Incident, Track, Train
from app.db.redis_client import redis_client
import json

router = APIRouter(prefix="/incidents", tags=["Incident Management"])

@router.get("")
def get_incidents(status: str = None, session: Session = Depends(get_session)):
    """Fetches list of active or historic incidents."""
    query = select(Incident)
    if status:
        query = query.where(Incident.status == status)
    query = query.order_by(Incident.created_at.desc())
    return session.exec(query).all()

@router.post("/{incident_id}/resolve")
def resolve_incident(incident_id: UUID, session: Session = Depends(get_session)):
    """Manually clears an incident, resetting tracks to GREEN and trains to OPERATIONAL."""
    incident = session.get(Incident, incident_id)
    if not incident:
        raise HTTPException(status_code=404, detail="Incident not found.")

    incident.status = "RESOLVED"
    session.add(incident)

    # Reset associated Track
    if incident.track_id:
        track = session.get(Track, incident.track_id)
        if track:
            track.status = "GREEN"
            session.add(track)

    # Reset associated Train
    if incident.train_id:
        train = session.get(Train, incident.train_id)
        if train:
            train.status = "OPERATIONAL"
            session.add(train)

    session.commit()

    # Broadcast event
    redis_client.publish("live_telemetry", json.dumps({
        "event": "incident_resolved",
        "incident_id": str(incident_id),
        "status": "RESOLVED"
    }))

    return {"status": "success", "message": f"Incident {incident.code} resolved."}
