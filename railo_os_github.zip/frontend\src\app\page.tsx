"use client";

import { useEffect, useState, useRef } from "react";
import { 
  Shield, AlertTriangle, Train as TrainIcon, Settings, Cpu, Map, Activity, 
  Bell, CheckCircle2, Clock, Play, Square, AlertCircle, Compass, 
  Database, DollarSign, RefreshCw, Eye, HelpCircle, Flame
} from "lucide-react";
import { 
  LineChart, Line, ResponsiveContainer, XAxis, YAxis, Tooltip, 
  AreaChart, Area, BarChart, Bar, CartesianGrid 
} from "recharts";
import { api, StationData, TrackData, TrainData, IncidentData, DeviceStatusData, WS_BASE_URL } from "./services/api";
import ThreeTwin from "./components/ThreeTwin";

export default function RailOSDashboard() {
  const [activeTab, setActiveTab] = useState<string>("command");
  const [digitalTwin, setDigitalTwin] = useState<any>(null);
  const [sensors, setSensors] = useState<DeviceStatusData[]>([]);
  const [agents, setAgents] = useState<any[]>([]);
  const [agentLogs, setAgentLogs] = useState<any[]>([]);
  const [socketConnected, setSocketConnected] = useState<boolean>(false);
  const [simRunning, setSimRunning] = useState<boolean>(true);
  const [activeIncident, setActiveIncident] = useState<IncidentData | null>(null);
  
  // Custom simulator triggers
  const [selectedTrack, setSelectedTrack] = useState<string>("TR-NDLS-CSMT");
  const [anomalyType, setAnomalyType] = useState<string>("fracture");

  // Telemetry rolling charts state
  const [vibrationHistory, setVibrationHistory] = useState<any[]>([]);
  const [mounted, setMounted] = useState<boolean>(false);
  const wsRef = useRef<WebSocket | null>(null);

  // Time clock ticking state
  const [timeStr, setTimeStr] = useState<string>("");

  useEffect(() => {
    setMounted(true);
    
    // Ticking Clock
    const updateTime = () => {
      const d = new Date();
      setTimeStr(d.toLocaleTimeString() + " | " + d.toLocaleDateString());
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);

    // Initial boot fetch
    fetchInitialData();

    // Setup Websocket
    connectWebSocket();

    return () => {
      clearInterval(interval);
      if (wsRef.current) wsRef.current.close();
    };
  }, []);

  const fetchInitialData = async () => {
    try {
      const dtState = await api.fetchDigitalTwin();
      setDigitalTwin(dtState);
      
      const sensorState = await api.fetchSensors();
      setSensors(sensorState);

      const agentState = await api.fetchAgentStatus();
      setAgents(agentState);

      // Extract active open/contained incident if any
      const activeInc = dtState.incidents.find(i => i.status !== "RESOLVED");
      if (activeInc) {
        setActiveIncident(activeInc);
      } else {
        setActiveIncident(null);
      }
    } catch (err) {
      console.error("Failed to sync initial database boot state:", err);
    }
  };

  const connectWebSocket = () => {
    console.log("Connecting to RailOS WebSocket Gateway:", WS_BASE_URL);
    const ws = new WebSocket(WS_BASE_URL);
    wsRef.current = ws;

    ws.onopen = () => {
      setSocketConnected(true);
      console.log("WebSocket stream connected.");
    };

    ws.onclose = () => {
      setSocketConnected(false);
      console.log("WebSocket stream closed. Retrying...");
      setTimeout(connectWebSocket, 5000);
    };

    ws.onmessage = (event) => {
      try {
        const payload = JSON.parse(event.data);
        handleWsEvent(payload);
      } catch (err) {
        console.error("Error parsing WebSocket frame:", err);
      }
    };
  };

  const handleWsEvent = (payload: any) => {
    if (payload.event === "sensor_update") {
      // Update sensor list
      setSensors(prev => prev.map(s => {
        if (s.id === payload.device_id) {
          return {
            ...s,
            latest_metrics: payload.metrics,
            last_ping: payload.timestamp
          };
        }
        return s;
      }));

      // Append to charts history
      if (payload.device_type === "VIBRATION") {
        setVibrationHistory(prev => {
          const updated = [...prev, {
            time: new Date(payload.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
            val: payload.metrics.vibration
          }];
          return updated.slice(-15); // limit length
        });
      }
    }

    if (payload.event === "train_positions") {
      setDigitalTwin(prev => {
        if (!prev) return prev;
        // Map WS values to existing train format
        const updatedTrains = prev.trains.map((t: any) => {
          const match = payload.trains.find((ut: any) => ut.code === t.code);
          if (match) {
            return {
              ...t,
              latitude: match.latitude,
              longitude: match.longitude,
              speed: match.speed,
              status: match.status
            };
          }
          return t;
        });
        return { ...prev, trains: updatedTrains };
      });
    }

    if (payload.event === "incident_resolved_step" || payload.event === "incident_resolved") {
      // Trigger full refresh of digital twin to capture containment action steps
      fetchInitialData();
    }
  };

  // UI Event Handlers
  const handleTriggerAnomaly = async () => {
    try {
      await api.triggerAnomaly(anomalyType, selectedTrack);
      await fetchInitialData();
      // Auto transition to emergency command screen to view agent execution plans
      setActiveTab("emergency");
    } catch (err) {
      alert("Failed to inject simulation event.");
    }
  };

  const handleClearAnomalies = async () => {
    try {
      await api.clearAnomalies();
      await fetchInitialData();
      setActiveIncident(null);
    } catch (err) {
      alert("Failed to clear anomalies.");
    }
  };

  const handleResolveIncident = async (id: string) => {
    try {
      await api.resolveIncident(id);
      await fetchInitialData();
      setActiveIncident(null);
    } catch (err) {
      alert("Error resolving incident.");
    }
  };

  const toggleSimulation = async () => {
    try {
      if (simRunning) {
        await api.stopSimulation();
        setSimRunning(false);
      } else {
        await api.startSimulation();
        setSimRunning(true);
      }
    } catch (err) {
      console.error(err);
    }
  };

  if (!mounted || !digitalTwin) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-slate-950 text-cyan-400 gap-4">
        <RefreshCw className="animate-spin w-10 h-10" />
        <span className="font-mono text-sm tracking-wider">BOOTING RAILOS CORE SERVICE GATEWAY...</span>
      </div>
    );
  }

  // Count metrics helper
  const openIncidents = digitalTwin.incidents.filter((i: any) => i.status !== "RESOLVED");
  const isEmergency = openIncidents.length > 0;

  return (
    <div className={`flex flex-col min-h-screen ${isEmergency ? 'border-2 border-rose-600/20' : ''}`}>
      
      {/* Alarm System Glow Screen Overlay */}
      {isEmergency && (
        <div className="absolute inset-0 bg-red-950/10 pointer-events-none animate-emergency-flash -z-10" />
      )}

      {/* Main Top Header Bar */}
      <header className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/90 backdrop-blur-md relative z-10">
        <div className="flex items-center gap-3">
          <div className="w-3 h-3 bg-cyan-400 rounded-full animate-pulse-glow" />
          <h1 className="text-xl font-bold tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-indigo-400 to-indigo-600">
            RAILOS
          </h1>
          <span className="px-2 py-0.5 rounded text-[10px] bg-slate-800 text-slate-400 border border-slate-700 font-mono">
            V1.0.0-PROD
          </span>
        </div>

        {/* Dynamic Alert Banner Ticker */}
        {isEmergency ? (
          <div className="flex items-center gap-2 text-rose-500 font-mono text-xs px-4 py-1 rounded border border-rose-600/30 bg-rose-950/25 animate-pulse">
            <AlertCircle className="w-4 h-4 animate-bounce" />
            <span>EMERGENCY DIRECTIVE IN EFFECT: {openIncidents[0].type} ON {openIncidents[0].track_code}</span>
          </div>
        ) : (
          <div className="flex items-center gap-2 text-emerald-400 font-mono text-xs px-4 py-1 rounded border border-emerald-500/20 bg-emerald-950/10">
            <CheckCircle2 className="w-4 h-4" />
            <span>ALL NETWORKS NOMINAL - DISPATCHERS ONLINE</span>
          </div>
        )}

        <div className="flex items-center gap-4">
          {/* WebSocket Status Indicator */}
          <div className="flex items-center gap-1.5 bg-slate-900 px-3 py-1 rounded-full border border-slate-800">
            <div className={`w-2 h-2 rounded-full ${socketConnected ? 'bg-emerald-400' : 'bg-red-500'}`} />
            <span className="text-[10px] font-mono uppercase text-slate-400">
              {socketConnected ? 'Gateway Live' : 'Connecting'}
            </span>
          </div>

          <div className="font-mono text-xs text-slate-400 flex items-center gap-2">
            <Clock className="w-3.5 h-3.5 text-cyan-400" />
            <span>{timeStr}</span>
          </div>
        </div>
      </header>

      {/* Main Workspace Frame */}
      <div className="flex flex-1 overflow-hidden">
        
        {/* Sidebar Nav Panels */}
        <aside className="w-64 border-r border-slate-800 bg-slate-950/80 backdrop-blur-md flex flex-col justify-between p-4 relative z-10">
          <div className="space-y-1">
            <span className="text-[9px] font-mono tracking-widest text-slate-500 uppercase px-3 block mb-3">COMMAND SYSTEMS</span>
            
            <button
              onClick={() => setActiveTab("command")}
              className={`flex items-center gap-3 w-full px-3 py-2.5 rounded-lg text-sm transition-all font-medium ${
                activeTab === "command" 
                  ? "bg-gradient-to-r from-cyan-500/10 to-indigo-500/10 text-cyan-400 border-l-2 border-cyan-400" 
                  : "text-slate-400 hover:bg-slate-900 hover:text-slate-200"
              }`}
            >
              <Activity className="w-4 h-4" />
              Executive Command
            </button>

            <button
              onClick={() => setActiveTab("network")}
              className={`flex items-center gap-3 w-full px-3 py-2.5 rounded-lg text-sm transition-all font-medium ${
                activeTab === "network" 
                  ? "bg-gradient-to-r from-cyan-500/10 to-indigo-500/10 text-cyan-400 border-l-2 border-cyan-400" 
                  : "text-slate-400 hover:bg-slate-900 hover:text-slate-200"
              }`}
            >
              <Map className="w-4 h-4" />
              Live 3D Digital Twin
            </button>

            <button
              onClick={() => setActiveTab("safety")}
              className={`flex items-center gap-3 w-full px-3 py-2.5 rounded-lg text-sm transition-all font-medium ${
                activeTab === "safety" 
                  ? "bg-gradient-to-r from-cyan-500/10 to-indigo-500/10 text-cyan-400 border-l-2 border-cyan-400" 
                  : "text-slate-400 hover:bg-slate-900 hover:text-slate-200"
              }`}
            >
              <Shield className="w-4 h-4" />
              Safety AI Predictors
            </button>

            <button
              onClick={() => setActiveTab("emergency")}
              className={`flex items-center gap-3 w-full px-3 py-2.5 rounded-lg text-sm transition-all font-medium relative ${
                activeTab === "emergency" 
                  ? "bg-gradient-to-r from-cyan-500/10 to-indigo-500/10 text-cyan-400 border-l-2 border-cyan-400" 
                  : "text-slate-400 hover:bg-slate-900 hover:text-slate-200"
              }`}
            >
              <AlertTriangle className="w-4 h-4" />
              Emergency Ops Room
              {isEmergency && (
                <span className="absolute right-3 top-3 w-2 h-2 rounded-full bg-red-500 animate-ping" />
              )}
            </button>

            <button
              onClick={() => setActiveTab("logistics")}
              className={`flex items-center gap-3 w-full px-3 py-2.5 rounded-lg text-sm transition-all font-medium ${
                activeTab === "logistics" 
                  ? "bg-gradient-to-r from-cyan-500/10 to-indigo-500/10 text-cyan-400 border-l-2 border-cyan-400" 
                  : "text-slate-400 hover:bg-slate-900 hover:text-slate-200"
              }`}
            >
              <Compass className="w-4 h-4" />
              Logistics & Routing
            </button>

            <button
              onClick={() => setActiveTab("agents")}
              className={`flex items-center gap-3 w-full px-3 py-2.5 rounded-lg text-sm transition-all font-medium ${
                activeTab === "agents" 
                  ? "bg-gradient-to-r from-cyan-500/10 to-indigo-500/10 text-cyan-400 border-l-2 border-cyan-400" 
                  : "text-slate-400 hover:bg-slate-900 hover:text-slate-200"
              }`}
            >
              <Cpu className="w-4 h-4" />
              Multi-Agent Engine
            </button>

            <button
              onClick={() => setActiveTab("devices")}
              className={`flex items-center gap-3 w-full px-3 py-2.5 rounded-lg text-sm transition-all font-medium ${
                activeTab === "devices" 
                  ? "bg-gradient-to-r from-cyan-500/10 to-indigo-500/10 text-cyan-400 border-l-2 border-cyan-400" 
                  : "text-slate-400 hover:bg-slate-900 hover:text-slate-200"
              }`}
            >
              <Settings className="w-4 h-4" />
              IoT & Sim Overrides
            </button>
          </div>

          {/* Simulation Status / Controls */}
          <div className="glass-panel p-3.5 rounded-xl border border-slate-800 bg-slate-950/60">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] font-mono text-slate-400 uppercase">TELEMETRY LOOPS</span>
              <span className={`text-[10px] font-mono ${simRunning ? 'text-cyan-400' : 'text-slate-500'}`}>
                {simRunning ? 'Running' : 'Paused'}
              </span>
            </div>
            <button 
              onClick={toggleSimulation}
              className={`w-full py-1.5 rounded text-xs font-mono transition-all flex items-center justify-center gap-2 ${
                simRunning 
                  ? 'bg-rose-950/40 text-rose-400 border border-rose-800/50 hover:bg-rose-900/40' 
                  : 'bg-cyan-950/40 text-cyan-400 border border-cyan-800/50 hover:bg-cyan-900/40'
              }`}
            >
              {simRunning ? (
                <>
                  <Square className="w-3.5 h-3.5 fill-rose-400" /> Stop Simulation
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 fill-cyan-400" /> Start Simulation
                </>
              )}
            </button>
          </div>
        </aside>

        {/* Dynamic Main Workspace Content */}
        <main className="flex-1 overflow-y-auto p-6 cyber-grid relative z-0">
          
          {/* TAB 1: EXECUTIVE COMMAND CENTER */}
          {activeTab === "command" && (
            <div className="space-y-6">
              
              {/* Header Ticker */}
              <div>
                <h2 className="text-2xl font-bold tracking-tight text-white">System Command Center</h2>
                <p className="text-xs text-slate-400 font-mono">Consolidated operational telemetry & multi-agent directives.</p>
              </div>

              {/* Status Metric Grid */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="glass-panel p-4 rounded-xl relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-16 h-16 bg-cyan-500/5 rounded-full filter blur-xl" />
                  <span className="text-[10px] font-mono text-slate-400 uppercase">Active Trains</span>
                  <div className="text-3xl font-bold mt-1 text-white">{digitalTwin.trains.length}</div>
                  <div className="text-[10px] font-mono text-emerald-400 mt-2 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" />
                    <span>In-transit telemetry nominal</span>
                  </div>
                </div>

                <div className="glass-panel p-4 rounded-xl relative overflow-hidden">
                  <span className="text-[10px] font-mono text-slate-400 uppercase">IoT Device Count</span>
                  <div className="text-3xl font-bold mt-1 text-white">{sensors.length}</div>
                  <div className="text-[10px] font-mono text-cyan-400 mt-2 flex items-center gap-1">
                    <Database className="w-3 h-3" />
                    <span>Gateway buffer online</span>
                  </div>
                </div>

                <div className="glass-panel p-4 rounded-xl relative overflow-hidden border-rose-500/20">
                  <span className="text-[10px] font-mono text-slate-400 uppercase">Unresolved Incidents</span>
                  <div className="text-3xl font-bold mt-1 text-rose-500">{openIncidents.length}</div>
                  <div className="text-[10px] font-mono text-rose-400 mt-2 flex items-center gap-1">
                    <AlertTriangle className="w-3 h-3" />
                    <span>Requires Emergency Protocol</span>
                  </div>
                </div>

                <div className="glass-panel p-4 rounded-xl relative overflow-hidden">
                  <span className="text-[10px] font-mono text-slate-400 uppercase">Logistics Cost Index</span>
                  <div className="text-3xl font-bold mt-1 text-indigo-400">$3,420.50</div>
                  <div className="text-[10px] font-mono text-indigo-400 mt-2 flex items-center gap-1">
                    <DollarSign className="w-3 h-3" />
                    <span>Fuel usage optimized</span>
                  </div>
                </div>
              </div>

              {/* Bottom Visual Modules (Grid split) */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                
                {/* Visual Map Module */}
                <div className="lg:col-span-2 glass-panel p-4 rounded-xl flex flex-col min-h-[400px]">
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-xs font-mono text-slate-300 uppercase">DIGITAL TWIN PIPELINE (2D INTERACTIVE)</span>
                    <span className="text-[10px] font-mono text-cyan-400">Click station to target</span>
                  </div>
                  
                  {/* High Fidelity SVG Vector Map */}
                  <div className="flex-1 bg-slate-950/80 rounded-lg border border-slate-900 relative p-4 flex items-center justify-center min-h-[300px]">
                    <svg viewBox="0 0 800 500" className="w-full h-full max-h-[350px]">
                      {/* Grid background inside SVG */}
                      <defs>
                        <pattern id="smallGrid" width="20" height="20" patternUnits="userSpaceOnUse">
                          <path d="M 20 0 L 0 0 0 20" fill="none" stroke="rgba(0, 255, 240, 0.02)" strokeWidth="0.5"/>
                        </pattern>
                      </defs>
                      <rect width="100%" height="100%" fill="url(#smallGrid)" />

                      {/* Rail Lines */}
                      {digitalTwin.tracks.map((track: any) => {
                        if (!track.start_station || !track.end_station) return null;
                        
                        // Project lat/lon to fit SVG container (X: [72, 89] -> [50, 750], Y: [12, 29] -> [450, 50])
                        const scaleX = (lon: number) => 50 + ((lon - 72) / 17) * 700;
                        const scaleY = (lat: number) => 450 - ((lat - 12) / 17) * 400;

                        const x1 = scaleX(track.start_station.lon);
                        const y1 = scaleY(track.start_station.lat);
                        const x2 = scaleX(track.end_station.lon);
                        const y2 = scaleY(track.end_station.lat);

                        let strokeColor = "rgba(59, 130, 246, 0.4)"; // Blue
                        let strokeWidth = "2";
                        let isDashed = false;

                        if (track.status === "YELLOW") strokeColor = "#ffaa00";
                        if (track.status === "RED") strokeColor = "#ef4444";
                        if (track.status === "EMERGENCY") {
                          strokeColor = "#ff003c";
                          strokeWidth = "3";
                          isDashed = true;
                        }

                        return (
                          <g key={track.id}>
                            <line 
                              x1={x1} y1={y1} x2={x2} y2={y2} 
                              stroke={strokeColor} 
                              strokeWidth={strokeWidth}
                              strokeDasharray={isDashed ? "4,4" : "none"}
                              className={track.status === "EMERGENCY" ? "animate-pulse" : ""}
                            />
                            <text 
                              x={(x1+x2)/2} y={(y1+y2)/2 - 5} 
                              fill="rgba(255,255,255,0.25)" 
                              fontSize="7" 
                              fontFamily="monospace"
                              textAnchor="middle"
                            >
                              {track.code}
                            </text>
                          </g>
                        );
                      })}

                      {/* Stations */}
                      {digitalTwin.stations.map((s: any) => {
                        const scaleX = (lon: number) => 50 + ((lon - 72) / 17) * 700;
                        const scaleY = (lat: number) => 450 - ((lat - 12) / 17) * 400;

                        const x = scaleX(s.longitude);
                        const y = scaleY(s.latitude);

                        return (
                          <g key={s.id}>
                            <circle cx={x} cy={y} r="6" fill="#020617" stroke="#00fff0" strokeWidth="2" />
                            <circle cx={x} cy={y} r="2" fill="#00fff0" />
                            <text x={x} y={y - 12} fill="#fff" fontSize="9" fontWeight="bold" fontFamily="monospace" textAnchor="middle">
                              {s.code}
                            </text>
                            <text x={x} y={y + 16} fill="rgba(255,255,255,0.4)" fontSize="6" fontFamily="sans-serif" textAnchor="middle">
                              {s.name}
                            </text>
                          </g>
                        );
                      })}

                      {/* Trains */}
                      {digitalTwin.trains.map((t: any) => {
                        const scaleX = (lon: number) => 50 + ((lon - 72) / 17) * 700;
                        const scaleY = (lat: number) => 450 - ((lat - 12) / 17) * 400;

                        const x = scaleX(t.longitude);
                        const y = scaleY(t.latitude);

                        let color = "#39ff14"; // operational green
                        if (t.status === "CRITICAL" || t.status === "STOPPED") color = "#ff003c";

                        return (
                          <g key={t.id} className="transition-all duration-1000">
                            <polygon 
                              points={`${x},${y-6} ${x-5},${y+4} ${x+5},${y+4}`} 
                              fill={color} 
                              stroke="#000" 
                              strokeWidth="1" 
                            />
                            <text x={x + 10} y={y + 3} fill={color} fontSize="7" fontFamily="monospace" fontWeight="bold">
                              {t.code} ({Math.round(t.speed)}km/h)
                            </text>
                          </g>
                        );
                      })}
                    </svg>
                  </div>
                </div>

                {/* Right Side Alerts panel */}
                <div className="glass-panel p-4 rounded-xl flex flex-col">
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-xs font-mono text-slate-300 uppercase">Live Alert Stream</span>
                    <Bell className="w-4 h-4 text-cyan-400" />
                  </div>

                  <div className="flex-1 space-y-3 overflow-y-auto max-h-[320px] pr-2">
                    {digitalTwin.alerts.length === 0 ? (
                      <div className="flex flex-col items-center justify-center h-full text-slate-500 font-mono text-xs gap-2 py-12">
                        <CheckCircle2 className="w-8 h-8 text-emerald-500/40" />
                        No warnings recorded
                      </div>
                    ) : (
                      digitalTwin.alerts.map((al: any) => (
                        <div 
                          key={al.id} 
                          className={`p-3 rounded-lg border text-xs font-mono ${
                            al.level === "EMERGENCY" 
                              ? 'bg-rose-950/20 border-rose-600/30 text-rose-400' 
                              : 'bg-amber-950/10 border-amber-600/20 text-amber-400'
                          }`}
                        >
                          <div className="flex justify-between items-center mb-1">
                            <span className="font-bold">{al.level}</span>
                            <span className="text-[9px] text-slate-500">{new Date(al.created_at).toLocaleTimeString()}</span>
                          </div>
                          <p>{al.message}</p>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: LIVE 3D DIGITAL TWIN */}
          {activeTab === "network" && (
            <div className="space-y-6 h-full flex flex-col">
              <div>
                <h2 className="text-2xl font-bold text-white">Digital Twin Visualizer</h2>
                <p className="text-xs text-slate-400 font-mono">Real-time WebGL space rendering topology coordinates.</p>
              </div>

              <div className="flex-1 min-h-[500px]">
                <ThreeTwin 
                  stations={digitalTwin.stations} 
                  tracks={digitalTwin.tracks} 
                  trains={digitalTwin.trains} 
                />
              </div>
            </div>
          )}

          {/* TAB 3: SAFETY INTELLIGENCE CENTER */}
          {activeTab === "safety" && (
            <div className="space-y-6">
              <div>
                <h2 className="text-2xl font-bold text-white">Safety Intelligence Center</h2>
                <p className="text-xs text-slate-400 font-mono">XGBoost & Isolation Forest telemetry analysis models.</p>
              </div>

              {/* ML model specs */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="glass-panel p-4 rounded-xl">
                  <span className="text-[10px] font-mono text-cyan-400 uppercase">Core Model</span>
                  <h3 className="text-lg font-bold mt-1 text-white">Isolation Forest Anomaly</h3>
                  <p className="text-xs text-slate-400 mt-2">Trains unsupervised multi-dimensional vectors (Vibration + Tilt + Temp) to identify outliers outside acceptable threshold boundaries.</p>
                </div>
                
                <div className="glass-panel p-4 rounded-xl">
                  <span className="text-[10px] font-mono text-cyan-400 uppercase">Detection Framework</span>
                  <h3 className="text-lg font-bold mt-1 text-white">YOLOv8 Camera Inference</h3>
                  <p className="text-xs text-slate-400 mt-2">Monitors visual feeds from ESP32-CAM devices to automatically register track fractures and structural obstructions.</p>
                </div>

                <div className="glass-panel p-4 rounded-xl">
                  <span className="text-[10px] font-mono text-cyan-400 uppercase">Feature Weight</span>
                  <h3 className="text-lg font-bold mt-1 text-white">XGBoost Weights</h3>
                  <div className="space-y-1 mt-2 font-mono text-[10px]">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Vibration Delta</span>
                      <span className="text-cyan-400">45.2%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Tilt Deflection</span>
                      <span className="text-cyan-400">38.1%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Temperature Rise</span>
                      <span className="text-cyan-400">16.7%</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Dynamic Line Charts */}
              <div className="glass-panel p-5 rounded-xl">
                <span className="text-xs font-mono text-slate-300 uppercase mb-4 block">Vibration Stream Telemetry (High-Frequency)</span>
                <div className="h-64">
                  {vibrationHistory.length === 0 ? (
                    <div className="flex items-center justify-center h-full text-slate-500 font-mono text-xs">
                      Waiting for telemetry stream...
                    </div>
                  ) : (
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={vibrationHistory}>
                        <defs>
                          <linearGradient id="colorVib" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#00fff0" stopOpacity={0.3}/>
                            <stop offset="95%" stopColor="#00fff0" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <XAxis dataKey="time" stroke="#475569" fontSize={10} />
                        <YAxis stroke="#475569" fontSize={10} />
                        <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b' }} />
                        <Area type="monotone" dataKey="val" stroke="#00fff0" fillOpacity={1} fill="url(#colorVib)" strokeWidth={2} />
                      </AreaChart>
                    </ResponsiveContainer>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: EMERGENCY OPERATIONS CENTER */}
          {activeTab === "emergency" && (
            <div className="space-y-6">
              
              {/* Blink Header */}
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-2xl font-bold text-white">Emergency Control</h2>
                  <p className="text-xs text-slate-400 font-mono">Central Emergency Coordinator Agent action plans.</p>
                </div>
                
                {isEmergency && (
                  <button 
                    onClick={handleClearAnomalies}
                    className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-mono text-xs rounded transition-all flex items-center gap-2"
                  >
                    <Flame className="w-4 h-4 animate-spin" /> Clear Emergency State
                  </button>
                )}
              </div>

              {!isEmergency ? (
                <div className="glass-panel p-12 rounded-xl text-center space-y-3">
                  <CheckCircle2 className="w-16 h-16 text-emerald-500 mx-auto animate-pulse" />
                  <h3 className="text-lg font-bold text-white">No Active Emergencies</h3>
                  <p className="text-xs text-slate-400 font-mono max-w-md mx-auto">
                    The network safety score is at 100%. If an anomaly occurs, the Safety Agent will register an incident, forcing immediate containment protocols.
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  
                  {/* Left Side: Incident details */}
                  <div className="glass-panel p-5 rounded-xl space-y-4">
                    <span className="text-xs font-mono text-rose-500 uppercase flex items-center gap-1.5 font-bold">
                      <AlertTriangle className="w-4 h-4 animate-ping" />
                      CRITICAL ANOMALY ALERT
                    </span>
                    
                    <div className="border-b border-slate-800 pb-3">
                      <div className="text-2xl font-bold text-white mb-1">{openIncidents[0].type}</div>
                      <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-rose-950/50 text-rose-400 border border-rose-600/30">
                        {openIncidents[0].code}
                      </span>
                    </div>

                    <div className="space-y-2 font-mono text-xs">
                      <div>
                        <span className="text-slate-400">Track Location: </span>
                        <span className="text-white font-bold">{openIncidents[0].track_code}</span>
                      </div>
                      <div>
                        <span className="text-slate-400">Assigned Train: </span>
                        <span className="text-white font-bold">{openIncidents[0].train_code || "None"}</span>
                      </div>
                      <div>
                        <span className="text-slate-400">Detection Source: </span>
                        <span className="text-white">Safety ML Agent</span>
                      </div>
                      <div>
                        <span className="text-slate-400">Incident Narrative: </span>
                        <p className="text-slate-300 mt-1.5 p-3 rounded bg-slate-900 border border-slate-800">
                          {openIncidents[0].description}
                        </p>
                      </div>
                    </div>

                    <div className="pt-4">
                      <button 
                        onClick={() => handleResolveIncident(openIncidents[0].id)}
                        className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-mono text-sm rounded font-bold transition-all"
                      >
                        Acknowledge & Force Resolve Incident
                      </button>
                    </div>
                  </div>

                  {/* Right Side: Emergency Coordinator Plan */}
                  <div className="glass-panel p-5 rounded-xl space-y-4">
                    <span className="text-xs font-mono text-cyan-400 uppercase">Emergency Coordinator Action Checklist</span>
                    
                    <div className="space-y-4">
                      {openIncidents[0].action_plan?.checklist?.map((chk: any, idx: number) => (
                        <div key={idx} className="flex items-start gap-3 border-l-2 border-slate-800 pl-4 py-1">
                          <div className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5 ${
                            chk.completed ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500' : 'bg-slate-900 text-slate-600 border border-slate-700'
                          }`}>
                            {chk.completed ? (
                              <CheckCircle2 className="w-3.5 h-3.5" />
                            ) : (
                              <Clock className="w-3 h-3 animate-spin" />
                            )}
                          </div>
                          <div>
                            <div className={`text-xs font-mono font-bold ${chk.completed ? 'text-white' : 'text-slate-500'}`}>
                              {chk.step}
                            </div>
                            {chk.timestamp && (
                              <span className="text-[9px] text-slate-500 font-mono">
                                Executed: {new Date(chk.timestamp).toLocaleTimeString()}
                              </span>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 5: LOGISTICS & ROUTING */}
          {activeTab === "logistics" && (
            <div className="space-y-6">
              <div>
                <h2 className="text-2xl font-bold text-white">Logistics Control</h2>
                <p className="text-xs text-slate-400 font-mono">Freight scheduling calculations and NetworkX route optimization logs.</p>
              </div>

              {/* Cargo List */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 glass-panel p-4 rounded-xl">
                  <span className="text-xs font-mono text-slate-300 uppercase mb-3 block">Freight Allocation Registry</span>
                  <div className="overflow-x-auto">
                    <table className="w-full text-xs font-mono text-left">
                      <thead>
                        <tr className="border-b border-slate-800 text-slate-400 uppercase">
                          <th className="py-2">Cargo Code</th>
                          <th className="py-2">Weight</th>
                          <th className="py-2">Allocated Train</th>
                          <th className="py-2">Destination</th>
                          <th className="py-2">ETA Prediction</th>
                          <th className="py-2">Status</th>
                        </tr>
                      </thead>
                      <tbody>
                        {digitalTwin.cargos.map((c: any) => (
                          <tr key={c.id} className="border-b border-slate-900 hover:bg-slate-900/40">
                            <td className="py-3 font-bold text-cyan-400">{c.code}</td>
                            <td className="py-3 text-slate-300">{c.weight} Tons</td>
                            <td className="py-3 text-white">{c.train_code || "Staged"}</td>
                            <td className="py-3 text-white">{c.destination}</td>
                            <td className="py-3 text-indigo-300">{c.eta ? new Date(c.eta).toLocaleTimeString() : "N/A"}</td>
                            <td className="py-3">
                              <span className={`px-2 py-0.5 rounded text-[10px] ${
                                c.status === "IN_TRANSIT" ? 'bg-cyan-950/50 text-cyan-400 border border-cyan-800/30' : 'bg-slate-850 text-slate-400'
                              }`}>
                                {c.status}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                <div className="glass-panel p-4 rounded-xl space-y-4">
                  <span className="text-xs font-mono text-slate-300 uppercase">Path Recalculations</span>
                  
                  {isEmergency && openIncidents[0].action_plan ? (
                    <div className="space-y-3 font-mono text-xs">
                      <div className="p-3 bg-indigo-950/20 border border-indigo-800/30 rounded text-indigo-400">
                        <span className="font-bold">Bypass recalculation triggered!</span>
                        <p className="mt-1 text-[11px] text-slate-300">
                          Scheduling Agent recalculated routes avoiding blocked coordinate: {openIncidents[0].track_code}
                        </p>
                      </div>
                      
                      <div className="space-y-2">
                        {openIncidents[0].action_plan.routing_adjustments.map((ra: any, idx: number) => (
                          <div key={idx} className="p-2.5 bg-slate-900 border border-slate-850 rounded">
                            <div className="font-bold text-white mb-1">Train: {ra.train_code}</div>
                            <div className="text-[10px] text-cyan-400">
                              Path: {ra.result?.route_path?.join(" -> ") || "N/A"}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <div className="text-slate-500 font-mono text-xs py-12 text-center">
                      No active bypass adjustments required.
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB 6: MULTI-AGENT ENGINE */}
          {activeTab === "agents" && (
            <div className="space-y-6">
              <div>
                <h2 className="text-2xl font-bold text-white">Agent Monitoring Console</h2>
                <p className="text-xs text-slate-400 font-mono">Internal chain-of-thought timelines of autonomous agent networks.</p>
              </div>

              {/* Agent Grid cards */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                {agents.map((ag: any) => (
                  <div key={ag.id} className="glass-panel p-4 rounded-xl space-y-3 relative overflow-hidden">
                    <div className="flex justify-between items-center">
                      <span className="text-[10px] font-mono text-slate-400 uppercase">{ag.type}</span>
                      <span className={`w-2.5 h-2.5 rounded-full ${ag.status === "ACTIVE" ? 'bg-cyan-400 animate-pulse' : 'bg-slate-600'}`} />
                    </div>
                    
                    <div>
                      <h3 className="text-base font-bold text-white">{ag.name}</h3>
                      <span className="text-[9px] font-mono text-cyan-400 bg-cyan-950/30 px-1.5 py-0.5 rounded border border-cyan-850">
                        {ag.model}
                      </span>
                    </div>

                    <div className="text-[10px] font-mono text-slate-400 border-t border-slate-900 pt-2">
                      <span className="text-slate-500">Last Action:</span>
                      <p className="text-slate-200 mt-1 truncate">{ag.last_action}</p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Console Logs */}
              <div className="glass-panel p-4 rounded-xl flex flex-col h-96">
                <span className="text-xs font-mono text-slate-300 uppercase mb-3 block">Agent Decision Trace Stream</span>
                <div className="flex-1 bg-slate-950 p-4 rounded-lg border border-slate-900 font-mono text-xs overflow-y-auto space-y-2.5">
                  <div className="text-slate-500">[12:59:10] Safety Agent: Initializing vibration telemetry scan on NDLS Express line.</div>
                  <div className="text-slate-500">[12:59:11] Safety Agent: Vibration index = 0.22, normal distribution bounds ok.</div>
                  <div className="text-slate-500">[12:59:12] Scheduling Agent: Route load optimizer mapping SBC platform availability.</div>
                  
                  {isEmergency && openIncidents[0].action_plan && (
                    <>
                      <div className="text-rose-400 font-bold">[EMERGENCY TRIGGER] Safety Agent: Telemetry anomaly detected on {openIncidents[0].track_code}. Isolation Forest score exceeding contaminated boundaries.</div>
                      <div className="text-cyan-400 font-bold">[COORDINATION DECISION] Emergency Coordinator: Intercepting anomaly, invoking emergency directive containment protocols.</div>
                      <div className="text-indigo-400">[COORDINATION DECISION] Emergency Coordinator: Halting matching trains. Invoking Scheduling Agent to compute route detours.</div>
                      <div className="text-emerald-400">[BYPASS COMPLETE] Scheduling Agent: Recalculated Dijkstra detour bypass route on NetworkX railway topology.</div>
                    </>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB 7: IoT & SIMULATION OVERRIDES */}
          {activeTab === "devices" && (
            <div className="space-y-6">
              <div>
                <h2 className="text-2xl font-bold text-white">IoT Gateway & Simulation Overrides</h2>
                <p className="text-xs text-slate-400 font-mono">Manually register hardware gateways or inject virtual environmental anomalies.</p>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                
                {/* Left Side: Simulation controllers */}
                <div className="glass-panel p-5 rounded-xl space-y-5">
                  <span className="text-xs font-mono text-slate-300 uppercase block border-b border-slate-900 pb-2">Simulator Control Console</span>
                  
                  <div className="space-y-3 text-xs font-mono">
                    <div className="flex flex-col gap-1.5">
                      <label className="text-slate-400">Target Track Coordinates:</label>
                      <select 
                        value={selectedTrack} 
                        onChange={(e) => setSelectedTrack(e.target.value)}
                        className="p-2 rounded bg-slate-900 border border-slate-800 text-white font-mono"
                      >
                        {digitalTwin.tracks.map((t: any) => (
                          <option key={t.id} value={t.code}>{t.name} ({t.code})</option>
                        ))}
                      </select>
                    </div>

                    <div className="flex flex-col gap-1.5">
                      <label className="text-slate-400">Environmental Hazard Type:</label>
                      <select 
                        value={anomalyType} 
                        onChange={(e) => setAnomalyType(e.target.value)}
                        className="p-2 rounded bg-slate-900 border border-slate-800 text-white font-mono"
                      >
                        <option value="fracture">Steel Track Fracture Anomaly</option>
                        <option value="obstacle">Foreign Obstacle / Landslide</option>
                        <option value="flood">Flash Flooding / Track Submergence</option>
                      </select>
                    </div>

                    <div className="pt-4 flex gap-3">
                      <button 
                        onClick={handleTriggerAnomaly}
                        className="flex-1 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded font-bold transition-all"
                      >
                        Inject Anomaly
                      </button>
                      <button 
                        onClick={handleClearAnomalies}
                        className="flex-1 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded transition-all border border-slate-700"
                      >
                        Clear All
                      </button>
                    </div>
                  </div>
                </div>

                {/* Right Side: IoT node registry listings */}
                <div className="lg:col-span-2 glass-panel p-5 rounded-xl flex flex-col">
                  <span className="text-xs font-mono text-slate-300 uppercase mb-3 block">Sensor Gateway Node Registry</span>
                  
                  <div className="flex-1 overflow-y-auto max-h-[300px] pr-2">
                    <table className="w-full text-left text-xs font-mono">
                      <thead>
                        <tr className="border-b border-slate-850 text-slate-400 uppercase">
                          <th className="py-2">Node Name</th>
                          <th className="py-2">MAC Address</th>
                          <th className="py-2">Type</th>
                          <th className="py-2">Track Location</th>
                          <th className="py-2">Last Metrics</th>
                          <th className="py-2">Status</th>
                        </tr>
                      </thead>
                      <tbody>
                        {sensors.map((s) => (
                          <tr key={s.id} className="border-b border-slate-900 hover:bg-slate-900/40">
                            <td className="py-2.5 font-bold text-white">{s.name}</td>
                            <td className="py-2.5 text-slate-400">{s.mac_address}</td>
                            <td className="py-2.5 text-cyan-400 font-bold">{s.type}</td>
                            <td className="py-2.5 text-white">{s.track_code}</td>
                            <td className="py-2.5 text-indigo-300 text-[10px]">
                              {JSON.stringify(s.latest_metrics)}
                            </td>
                            <td className="py-2.5">
                              <span className="px-1.5 py-0.5 rounded text-[9px] bg-emerald-950/50 text-emerald-400 border border-emerald-800/30">
                                {s.status}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

              </div>
            </div>
          )}

        </main>
      </div>
    </div>
  );
}
