import redis
import logging
from app.core.config import settings

logger = logging.getLogger("railo_os.redis")

class MockRedis:
    """Fallback in-memory Redis-like store when Redis is unavailable."""
    def __init__(self):
        self.store = {}
        self.subscribers = {}
        logger.warning("Using in-memory MockRedis fallback.")

    def set(self, key, value, ex=None):
        self.store[key] = value
        return True

    def get(self, key):
        return self.store.get(key)

    def delete(self, key):
        if key in self.store:
            del self.store[key]
            return 1
        return 0

    def publish(self, channel, message):
        if channel in self.subscribers:
            for cb in self.subscribers[channel]:
                try:
                    cb(message)
                except Exception as e:
                    logger.error(f"Error calling sub callback: {e}")
        return 1

    def ping(self):
        return True

def get_redis_client():
    try:
        client = redis.from_url(settings.REDIS_URL, decode_responses=True)
        client.ping()
        return client
    except Exception as e:
        logger.error(f"Failed to connect to Redis at {settings.REDIS_URL}: {e}")
        return MockRedis()

redis_client = get_redis_client()
