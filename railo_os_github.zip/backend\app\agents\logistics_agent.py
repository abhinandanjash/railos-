import logging
from datetime import datetime, timedelta
from uuid import UUID
from sqlmodel import Session, select
from app.db.session import engine
from app.models.schemas import Cargo, Train, Track, Station, AgentLog

logger = logging.getLogger("railo_os.agents.logistics")

class LogisticsAgent:
    def __init__(self):
        self.name = "Logistics Agent"

    def optimize_cargo_dispatch(self, session: Session, cargo_id: UUID) -> dict:
        """Calculates transit costs and updates delivery ETA based on train metrics."""
        logger.info(f"Logistics Agent optimizing cargo route: {cargo_id}")

        cargo = session.get(Cargo, cargo_id)
        if not cargo:
            return {"status": "error", "message": "Cargo not found"}

        if not cargo.train_id:
            return {
                "status": "staged",
                "message": "Cargo is currently staged at depot. Awaiting train allocation."
            }

        train = session.get(Train, cargo.train_id)
        if not train:
            return {"status": "error", "message": "Allocated train not found"}

        # Calculate estimated distance (lat/long degrees to simplified km)
        dest_station = session.get(Station, cargo.destination_station_id)
        if not dest_station:
            return {"status": "error", "message": "Destination station not found"}

        lat_diff = dest_station.latitude - train.latitude
        lon_diff = dest_station.longitude - train.longitude
        distance_km = (lat_diff**2 + lon_diff**2)**0.5 * 111.0 # 1 degree lat is ~111km

        # Handle train speed variables
        speed = train.speed if train.speed > 5.0 else 50.0 # fallback default speed km/h
        
        # Calculate ETA
        travel_hours = distance_km / speed
        eta_time = datetime.utcnow() + timedelta(hours=travel_hours)

        # Cost Optimization calculations (simplistic logic based on fuel/weight metrics)
        fuel_cost_index = (cargo.weight * distance_km) * 0.15
        delay_cost_factor = 250.0 if train.status == "DELAYED" else 0.0
        total_estimated_cost = fuel_cost_index + delay_cost_factor

        # Update Cargo record
        cargo.eta = eta_time
        session.add(cargo)

        # Log decision
        log_entry = AgentLog(
            agent_name=self.name,
            action="CARGO_OPTIMIZATION",
            detail={
                "cargo_code": cargo.code,
                "weight_tons": cargo.weight,
                "distance_km": round(distance_km, 2),
                "estimated_cost_usd": round(total_estimated_cost, 2),
                "predicted_eta": eta_time.isoformat()
            },
            timestamp=datetime.utcnow()
        )
        session.add(log_entry)
        session.commit()

        return {
            "status": "success",
            "distance_km": round(distance_km, 2),
            "estimated_cost": round(total_estimated_cost, 2),
            "eta": eta_time.isoformat()
        }

logistics_agent = LogisticsAgent()
