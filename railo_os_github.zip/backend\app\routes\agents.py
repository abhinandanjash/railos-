from fastapi import APIRouter, Depends
from sqlmodel import Session, select
from app.db.session import get_session
from app.models.schemas import AgentLog

router = APIRouter(prefix="/agents", tags=["Agent Diagnostics"])

@router.get("/status")
def get_agents_status(session: Session = Depends(get_session)):
    """Exposes current agent status metrics and latest decision records."""
    agents = [
        {"id": "safety", "name": "Safety Agent", "type": "Predictive Failure", "model": "Isolation Forest / XGBoost"},
        {"id": "scheduling", "name": "Scheduling Agent", "type": "Route Optimization", "model": "NetworkX Dijkstra"},
        {"id": "logistics", "name": "Logistics Agent", "type": "Cargo Allocation & ETA", "model": "ETA Regression Cost Index"},
        {"id": "emergency", "name": "Emergency Coordinator", "type": "Central Action Orchestration", "model": "LangGraph State Machine"}
    ]

    results = []
    for ag in agents:
        # Get latest action logged by this agent
        latest_log = session.exec(
            select(AgentLog)
            .where(AgentLog.agent_name == ag["name"])
            .order_by(AgentLog.timestamp.desc())
        ).first()

        results.append({
            "id": ag["id"],
            "name": ag["name"],
            "type": ag["type"],
            "model": ag["model"],
            "status": "ACTIVE" if latest_log else "IDLE",
            "last_action": latest_log.action if latest_log else "None",
            "last_decision": latest_log.detail if latest_log else {},
            "last_timestamp": latest_log.timestamp.isoformat() if latest_log else None
        })

    return results

@router.get("/logs")
def get_agent_logs(limit: int = 50, session: Session = Depends(get_session)):
    """Retrieves standard audit trails of all agent thoughts/decisions."""
    query = select(AgentLog).order_by(AgentLog.timestamp.desc()).limit(limit)
    return session.exec(query).all()
