import logging
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.core.config import settings
from app.db.session import init_db
from app.db.seeds import seed_data
from app.simulator.engine import simulation_engine
from app.routes import auth, sensors, incidents, simulations, agents, digital_twin, ws, camera

# Setup logger configuration
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger("railo_os")

app = FastAPI(
    title="RailOS API",
    description="Autonomous Railway Intelligence Operating System - Service Gateway & Multi-Agent Core",
    version="1.0.0"
)

# CORS Policy configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # In production, lock down to matching frontend domain
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Attach API endpoints mapping
app.include_router(auth.router, prefix="/api/v1")
app.include_router(sensors.router, prefix="/api/v1")
app.include_router(incidents.router, prefix="/api/v1")
app.include_router(simulations.router, prefix="/api/v1")
app.include_router(agents.router, prefix="/api/v1")
app.include_router(digital_twin.router, prefix="/api/v1")
app.include_router(ws.router, prefix="/api/v1")
app.include_router(camera.router, prefix="/api/v1")

@app.on_event("startup")
async def startup_event():
    logger.info("Initializing RailOS database...")
    try:
        # Create tables
        init_db()
        # Seed core dataset
        seed_data()
    except Exception as e:
        logger.error(f"Error during startup migration/seeding: {e}", exc_info=True)

    logger.info("Starting simulation loop service...")
    simulation_engine.start()

@app.on_event("shutdown")
async def shutdown_event():
    logger.info("Stopping simulation loop service...")
    simulation_engine.stop()

@app.get("/")
def read_root():
    return {
        "status": "online",
        "system": "RailOS",
        "description": "Autonomous Railway Intelligence Operating System API Gateway"
    }
