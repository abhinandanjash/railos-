/**
 * RailOS ESP32 Firmware - MPU6050 Tilt / Gyroscope Sensor Node
 * =============================================================
 * Hardware: ESP32 DevKit + MPU6050 (6-axis IMU)
 * 
 * Wiring:
 *   MPU6050 VCC  → ESP32 3.3V
 *   MPU6050 GND  → ESP32 GND
 *   MPU6050 SDA  → ESP32 GPIO 21 (I2C Data)
 *   MPU6050 SCL  → ESP32 GPIO 22 (I2C Clock)
 *   MPU6050 INT  → ESP32 GPIO 19 (Optional interrupt pin)
 * 
 * Library Required: Install "MPU6050" by Electronic Cats from Arduino Library Manager
 * 
 * What it detects:
 *   - Track tilt / banking angle (degrees)
 *   - Vibration via accelerometer
 *   - Sudden rail displacement or derailment precursors
 */

#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <EEPROM.h>
#include <Wire.h>
#include <MPU6050.h>

// ============================================================
// CONFIGURATION
// ============================================================
const char* WIFI_SSID     = "YOUR_WIFI_SSID";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
const char* SERVER_IP     = "192.168.1.X"; // Your PC local IP
const int   SERVER_PORT   = 8000;
const char* TRACK_CODE    = "TR-NDLS-CSMT";

#define EEPROM_SIZE 512
#define DEVICE_ID_ADDR 0
#define TOKEN_ADDR 100

// ============================================================
// GLOBALS
// ============================================================
MPU6050 mpu;
String deviceId = "";
String deviceToken = "";
unsigned long lastReportTime = 0;
const unsigned long REPORT_INTERVAL_MS = 2000;

// ============================================================
// SETUP
// ============================================================
void setup() {
  Serial.begin(115200);
  Serial.println("=== RailOS MPU6050 Tilt Node ===");

  Wire.begin();
  mpu.initialize();

  if (!mpu.testConnection()) {
    Serial.println("MPU6050 connection FAILED. Check wiring!");
    while (1); // Halt
  }
  Serial.println("MPU6050 connected.");

  EEPROM.begin(EEPROM_SIZE);
  connectWiFi();
  loadCredentials();
  if (deviceId == "" || deviceToken == "") {
    registerDevice();
  } else {
    Serial.println("Loaded saved credentials. Device ID: " + deviceId);
  }
}

// ============================================================
// MAIN LOOP
// ============================================================
void loop() {
  if (millis() - lastReportTime >= REPORT_INTERVAL_MS) {
    int16_t ax, ay, az, gx, gy, gz;
    mpu.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);

    // Convert raw accelerometer to G forces
    float accel_x = ax / 16384.0;
    float accel_y = ay / 16384.0;
    float accel_z = az / 16384.0;

    // Compute tilt angle from accelerometer (in degrees)
    float tilt_pitch = atan2(accel_x, sqrt(accel_y * accel_y + accel_z * accel_z)) * 180.0 / PI;
    float tilt_roll  = atan2(accel_y, sqrt(accel_x * accel_x + accel_z * accel_z)) * 180.0 / PI;
    float tilt_magnitude = sqrt(tilt_pitch * tilt_pitch + tilt_roll * tilt_roll);

    // Vibration from gyroscope angular rate (deg/s)
    float gyro_magnitude = sqrt((float)gx*gx + (float)gy*gy + (float)gz*gz) / 131.0;

    Serial.printf("[MPU6050] Tilt: %.2f° | Gyro: %.2f°/s | Pitch: %.2f° Roll: %.2f°\n",
                  tilt_magnitude, gyro_magnitude, tilt_pitch, tilt_roll);

    postSensorData(tilt_magnitude, gyro_magnitude, accel_x, accel_y, accel_z);
    lastReportTime = millis();
  }
}

// ============================================================
// WIFI CONNECTION
// ============================================================
void connectWiFi() {
  Serial.printf("Connecting to WiFi: %s\n", WIFI_SSID);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nWiFi connected! IP: " + WiFi.localIP().toString());
}

// ============================================================
// DEVICE REGISTRATION
// ============================================================
void registerDevice() {
  Serial.println("Registering with RailOS Gateway...");
  HTTPClient http;
  String url = String("http://") + SERVER_IP + ":" + SERVER_PORT + "/api/v1/sensors/register";
  String mac = WiFi.macAddress();
  mac.replace(":", "");

  String payload = "{\"mac_address\":\"" + WiFi.macAddress() + 
                   "\",\"type\":\"TILT\",\"name\":\"ESP32-MPU6050-" + mac.substring(6) + 
                   "\",\"track_code\":\"" + TRACK_CODE + "\"}";

  http.begin(url);
  http.addHeader("Content-Type", "application/json");
  http.addHeader("Authorization", "Bearer ADMIN_JWT_TOKEN_HERE");

  int httpCode = http.POST(payload);
  if (httpCode == 201) {
    StaticJsonDocument<256> doc;
    deserializeJson(doc, http.getString());
    deviceId = doc["device_id"].as<String>();
    deviceToken = doc["token"].as<String>();
    saveCredentials();
    Serial.println("Registered! Device ID: " + deviceId);
  } else {
    Serial.printf("Registration failed. HTTP %d: %s\n", httpCode, http.getString().c_str());
  }
  http.end();
}

// ============================================================
// POST SENSOR DATA
// ============================================================
void postSensorData(float tilt, float gyro, float ax, float ay, float az) {
  if (WiFi.status() != WL_CONNECTED) { connectWiFi(); return; }

  HTTPClient http;
  String url = String("http://") + SERVER_IP + ":" + SERVER_PORT + "/api/v1/sensors/data";

  char payload[320];
  snprintf(payload, sizeof(payload),
    "{\"device_id\":\"%s\",\"metrics\":{\"tilt\":%.4f,\"gyro_rate\":%.4f,\"accel_x\":%.4f,\"accel_y\":%.4f,\"accel_z\":%.4f}}",
    deviceId.c_str(), tilt, gyro, ax, ay, az);

  http.begin(url);
  http.addHeader("Content-Type", "application/json");
  http.addHeader("Authorization", "Bearer " + deviceToken);

  int httpCode = http.POST(payload);
  Serial.printf("[%s] POST status: %d\n", httpCode == 200 ? "OK" : "ERR", httpCode);
  http.end();
}

// ============================================================
// EEPROM
// ============================================================
void saveCredentials() {
  EEPROM.writeString(DEVICE_ID_ADDR, deviceId);
  EEPROM.writeString(TOKEN_ADDR, deviceToken);
  EEPROM.commit();
}
void loadCredentials() {
  deviceId = EEPROM.readString(DEVICE_ID_ADDR);
  deviceToken = EEPROM.readString(TOKEN_ADDR);
  if (deviceId.length() < 10) deviceId = "";
  if (deviceToken.length() < 5) deviceToken = "";
}
