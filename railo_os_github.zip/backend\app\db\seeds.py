import logging
from sqlmodel import Session, select
from uuid import uuid4
from datetime import datetime
from app.db.session import engine
from app.db.neo4j_client import graph_manager
from app.models.schemas import Station, Track, Train, Cargo, Device, User
from app.core.security import get_password_hash

logger = logging.getLogger("railo_os.seeds")

def seed_data():
    with Session(engine) as session:
        # Check if users already seeded
        db_user = session.exec(select(User)).first()
        if db_user:
            logger.info("Database already seeded. Skipping seeder.")
            return

        logger.info("Initializing database seed data...")

        # 1. Create Default Architect User
        admin_user = User(
            username="admin",
            hashed_password=get_password_hash("admin123"),
            role="ADMIN"
        )
        session.add(admin_user)


        # 2. Define Stations
        stations_data = [
            {"code": "NDLS", "name": "New Delhi Central", "lat": 28.6415, "lon": 77.2197, "platforms": ["1", "2", "3", "4", "5"]},
            {"code": "CSMT", "name": "Mumbai Chhatrapati Shivaji", "lat": 18.9400, "lon": 72.8354, "platforms": ["1", "2", "3"]},
            {"code": "HWH", "name": "Kolkata Howrah Junction", "lat": 22.5834, "lon": 88.3426, "platforms": ["1", "2", "3", "4"]},
            {"code": "MAS", "name": "Chennai Central", "lat": 13.0827, "lon": 80.2707, "platforms": ["1", "2"]},
            {"code": "SBC", "name": "Bengaluru City Station", "lat": 12.9784, "lon": 77.5694, "platforms": ["1", "2", "3"]}
        ]

        stations = {}
        for s in stations_data:
            station_obj = Station(
                code=s["code"],
                name=s["name"],
                latitude=s["lat"],
                longitude=s["lon"],
                platforms=s["platforms"]
            )
            session.add(station_obj)
            stations[s["code"]] = station_obj

        session.commit()
        # Refresh to get IDs
        for k in stations:
            session.refresh(stations[k])
            # Add to local Neo4j graph manager
            graph_manager.add_station(
                station_id=str(stations[k].id),
                name=stations[k].name,
                code=stations[k].code,
                lat=stations[k].latitude,
                lon=stations[k].longitude,
                platforms=stations[k].platforms
            )

        # 3. Define Tracks connecting stations
        tracks_data = [
            ("NDLS", "CSMT", "TR-NDLS-CSMT", 140),
            ("NDLS", "HWH", "TR-NDLS-HWH", 130),
            ("CSMT", "SBC", "TR-CSMT-SBC", 110),
            ("SBC", "MAS", "TR-SBC-MAS", 100),
            ("MAS", "HWH", "TR-MAS-HWH", 120),
            ("NDLS", "SBC", "TR-NDLS-SBC", 130)
        ]

        tracks = {}
        for start_code, end_code, track_code, max_speed in tracks_data:
            start_st = stations[start_code]
            end_st = stations[end_code]
            track_obj = Track(
                code=track_code,
                name=f"{start_st.name} - {end_st.name} Express Line",
                start_station_id=start_st.id,
                end_station_id=end_st.id,
                max_speed=max_speed,
                status="GREEN"
            )
            session.add(track_obj)
            tracks[track_code] = track_obj

        session.commit()
        for k in tracks:
            session.refresh(tracks[k])
            graph_manager.add_track(
                track_id=str(tracks[k].id),
                code=tracks[k].code,
                start_station_id=str(tracks[k].start_station_id),
                end_station_id=str(tracks[k].end_station_id),
                max_speed=tracks[k].max_speed
            )

        # 4. Create Trains
        trains_data = [
            ("T-RAJDHANI", "Vande Bharat Express", "NDLS", "CSMT"),
            ("T-SHATABDI", "Shatabdi Logistics Bullet", "HWH", "NDLS"),
            ("T-HURRICANE", "Deccan Cargo Special", "CSMT", "SBC"),
            ("T-DURONTO", "Duronto Grid Runner", "SBC", "MAS")
        ]

        train_objs = []
        for code, name, start_station_code, end_station_code in trains_data:
            start_st = stations[start_station_code]
            track_code = f"TR-{start_station_code}-{end_station_code}"
            if track_code not in tracks:
                track_code = f"TR-{end_station_code}-{start_station_code}"
            
            track_id = tracks[track_code].id if track_code in tracks else None

            train_obj = Train(
                code=code,
                name=name,
                status="OPERATIONAL",
                current_track_id=track_id,
                current_station_id=start_st.id,
                latitude=start_st.latitude,
                longitude=start_st.longitude,
                speed=0.0
            )
            session.add(train_obj)
            train_objs.append(train_obj)

        session.commit()
        for tr in train_objs:
            session.refresh(tr)

        # 5. Create Cargo
        cargo_data = [
            ("C-IND-901", 120.5, "High-value industrial microcontrollers", "T-RAJDHANI", "CSMT"),
            ("C-COAL-802", 450.0, "Refined metallurgical coal load", "T-SHATABDI", "NDLS"),
            ("C-AGRI-103", 85.2, "Temperature-sensitive agricultural yield", "T-HURRICANE", "SBC")
        ]

        for code, weight, desc, train_code, dest_station_code in cargo_data:
            dest_st = stations[dest_station_code]
            target_train = next((t for t in train_objs if t.code == train_code), None)
            cargo_obj = Cargo(
                code=code,
                weight=weight,
                description=desc,
                train_id=target_train.id if target_train else None,
                destination_station_id=dest_st.id,
                eta=datetime.utcnow(),
                status="IN_TRANSIT"
            )
            session.add(cargo_obj)
            session.commit()
            session.refresh(cargo_obj)
            graph_manager.associate_cargo_destination(str(cargo_obj.id), str(dest_st.id))

        # 6. Add IoT Devices across tracks
        device_types = ["VIBRATION", "TILT", "TEMP", "ULTRASONIC", "CAMERA"]
        for t_idx, (t_code, track) in enumerate(tracks.items()):
            for d_idx, dev_type in enumerate(device_types):
                # Generate a globally unique MAC: use t_idx and d_idx as hex bytes
                mac_b1 = f"{t_idx:02X}"
                mac_b2 = f"{d_idx:02X}"
                device_mac = f"DE:AD:{mac_b1}:BE:{mac_b2}:EF"
                device_obj = Device(
                    mac_address=device_mac,
                    type=dev_type,
                    name=f"{track.code} Section {d_idx+1} {dev_type.title()}",
                    status="ONLINE",
                    track_id=track.id,
                    token=f"tok_{t_code}_{dev_type.lower()}_{d_idx}"
                )
                session.add(device_obj)

        session.commit()
        logger.info("Database seeding completed successfully.")
