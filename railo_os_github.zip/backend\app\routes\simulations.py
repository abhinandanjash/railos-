from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import Session, select
from app.db.session import get_session
from app.simulator.engine import simulation_engine
from app.models.schemas import SimulationEvent, Track
from pydantic import BaseModel
from uuid import UUID

router = APIRouter(prefix="/simulations", tags=["Simulation Control"])

class SimulationTriggerIn(BaseModel):
    type: str  # fracture, obstacle, flood
    track_code: str
    severity: str = "CRITICAL"

@router.post("/start")
def start_simulation():
    success = simulation_engine.start()
    return {
        "status": "running" if success or simulation_engine.is_running() else "error",
        "message": "Simulation engine running."
    }

@router.post("/stop")
def stop_simulation():
    success = simulation_engine.stop()
    return {
        "status": "stopped",
        "message": "Simulation engine stopped."
    }

@router.post("/trigger")
def trigger_scenario(data_in: SimulationTriggerIn, session: Session = Depends(get_session)):
    """Triggers an anomaly scenario on a specific track segment."""
    # Verify track code exists
    track = session.exec(select(Track).where(Track.code == data_in.track_code)).first()
    if not track:
        raise HTTPException(status_code=404, detail="Track segment code not found.")

    # Disable all prior active simulation events for this track
    prior_events = session.exec(
        select(SimulationEvent)
        .where(SimulationEvent.target == data_in.track_code)
        .where(SimulationEvent.active == True)
    ).all()
    
    for pe in prior_events:
        pe.active = False
        session.add(pe)

    # Insert new event
    new_event = SimulationEvent(
        type=data_in.type,
        target=data_in.track_code,
        severity=data_in.severity,
        details={"intensity": 1.0},
        active=True
    )
    session.add(new_event)
    session.commit()

    # Alert the running engine
    if simulation_engine.is_running():
        simulation_engine.trigger_anomaly(data_in.track_code, data_in.type, 1.0)

    return {
        "status": "triggered",
        "event_id": str(new_event.id),
        "message": f"Scenario {data_in.type} active on track {data_in.track_code}."
    }

@router.post("/clear")
def clear_scenarios(session: Session = Depends(get_session)):
    """Clears all active simulation anomalies."""
    active_events = session.exec(select(SimulationEvent).where(SimulationEvent.active == True)).all()
    for ae in active_events:
        ae.active = False
        session.add(ae)
    session.commit()

    simulation_engine.clear_anomalies()
    return {"status": "cleared", "message": "All simulation anomalies resolved."}
