import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "RailOS | Autonomous Railway Operating System",
  description: "SpaceX / Tesla-inspired Autonomous Railway Intelligence & Digital Twin",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="bg-slate-950 text-slate-100 min-h-screen flex flex-col antialiased">
        {children}
      </body>
    </html>
  );
}
