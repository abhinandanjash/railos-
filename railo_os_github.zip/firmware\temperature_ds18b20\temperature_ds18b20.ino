/**
 * RailOS ESP32 Firmware - DS18B20 Temperature Sensor Node
 * =========================================================
 * Hardware: ESP32 DevKit + DS18B20 Waterproof Temperature Sensor
 * 
 * Wiring (Parasite power mode):
 *   DS18B20 RED (VDD)    → ESP32 3.3V
 *   DS18B20 BLACK (GND)  → ESP32 GND
 *   DS18B20 YELLOW (DQ)  → ESP32 GPIO 4 + 4.7kΩ pull-up to 3.3V
 * 
 *   Pull-up resistor: 4.7kΩ between DQ and 3.3V is MANDATORY!
 * 
 * Libraries Required (Arduino Library Manager):
 *   - "OneWire" by Paul Stoffregen
 *   - "DallasTemperature" by Miles Burton
 * 
 * What it detects:
 *   - Track rail temperature (heat expansion, fire risks, brake friction)
 *   - Normal: 10°C - 40°C
 *   - WARNING: 40°C - 55°C (thermal stress on rails)
 *   - CRITICAL: > 55°C (rail buckling risk in extreme heat)
 *   - FLOOD indicator: Sudden drop below 5°C on summer tracks
 */

#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <EEPROM.h>
#include <OneWire.h>
#include <DallasTemperature.h>

// ============================================================
// CONFIGURATION
// ============================================================
const char* WIFI_SSID     = "YOUR_WIFI_SSID";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
const char* SERVER_IP     = "192.168.1.X"; // Your PC local IP
const int   SERVER_PORT   = 8000;
const char* TRACK_CODE    = "TR-NDLS-CSMT";

const int ONE_WIRE_PIN = 4; // DS18B20 data pin

// Temperature thresholds (°C)
const float TEMP_WARNING   = 40.0;
const float TEMP_CRITICAL  = 55.0;
const float TEMP_FLOOD_LOW = 5.0; // Suspiciously cold = possible flooding

#define EEPROM_SIZE 512
#define DEVICE_ID_ADDR 0
#define TOKEN_ADDR 100

// ============================================================
// GLOBALS
// ============================================================
OneWire oneWire(ONE_WIRE_PIN);
DallasTemperature sensors(&oneWire);
String deviceId = "";
String deviceToken = "";
unsigned long lastReportTime = 0;
const unsigned long REPORT_INTERVAL_MS = 5000; // 5s (DS18B20 is slower sensor)

// ============================================================
// SETUP
// ============================================================
void setup() {
  Serial.begin(115200);
  Serial.println("=== RailOS DS18B20 Temperature Node ===");

  sensors.begin();
  int deviceCount = sensors.getDeviceCount();
  Serial.printf("Found %d DS18B20 sensor(s) on bus.\n", deviceCount);

  if (deviceCount == 0) {
    Serial.println("ERROR: No DS18B20 found! Check wiring and pull-up resistor.");
    while(1);
  }

  EEPROM.begin(EEPROM_SIZE);
  connectWiFi();
  loadCredentials();
  if (deviceId == "" || deviceToken == "") {
    registerDevice();
  } else {
    Serial.println("Loaded credentials. Device ID: " + deviceId);
  }
}

// ============================================================
// MAIN LOOP
// ============================================================
void loop() {
  if (millis() - lastReportTime >= REPORT_INTERVAL_MS) {
    sensors.requestTemperatures();
    float tempC = sensors.getTempCByIndex(0);

    if (tempC == DEVICE_DISCONNECTED_C) {
      Serial.println("ERROR: DS18B20 disconnected!");
      lastReportTime = millis();
      return;
    }

    // Classify the temperature reading
    String thermalStatus = "NORMAL";
    if (tempC > TEMP_CRITICAL) {
      thermalStatus = "CRITICAL";
      Serial.printf("🚨 CRITICAL HEAT: %.2f°C — Rail buckling risk!\n", tempC);
    } else if (tempC > TEMP_WARNING) {
      thermalStatus = "WARNING";
      Serial.printf("⚠️  HIGH TEMP: %.2f°C — Thermal stress\n", tempC);
    } else if (tempC < TEMP_FLOOD_LOW) {
      thermalStatus = "FLOOD_INDICATOR";
      Serial.printf("❄️  LOW TEMP: %.2f°C — Possible flooding/icing\n", tempC);
    } else {
      Serial.printf("[DS18B20] Temperature: %.2f°C — Normal\n", tempC);
    }

    postSensorData(tempC, thermalStatus);
    lastReportTime = millis();
  }
}

// ============================================================
// WIFI CONNECTION
// ============================================================
void connectWiFi() {
  Serial.printf("Connecting to WiFi: %s\n", WIFI_SSID);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nWiFi connected! IP: " + WiFi.localIP().toString());
}

// ============================================================
// DEVICE REGISTRATION
// ============================================================
void registerDevice() {
  Serial.println("Registering with RailOS Gateway...");
  HTTPClient http;
  String url = String("http://") + SERVER_IP + ":" + SERVER_PORT + "/api/v1/sensors/register";
  String mac = WiFi.macAddress();
  mac.replace(":", "");

  String payload = "{\"mac_address\":\"" + WiFi.macAddress() + 
                   "\",\"type\":\"TEMP\",\"name\":\"ESP32-DS18B20-" + mac.substring(6) + 
                   "\",\"track_code\":\"" + TRACK_CODE + "\"}";

  http.begin(url);
  http.addHeader("Content-Type", "application/json");
  http.addHeader("Authorization", "Bearer ADMIN_JWT_TOKEN_HERE");

  int httpCode = http.POST(payload);
  if (httpCode == 201) {
    StaticJsonDocument<256> doc;
    deserializeJson(doc, http.getString());
    deviceId = doc["device_id"].as<String>();
    deviceToken = doc["token"].as<String>();
    saveCredentials();
    Serial.println("Registered! Device ID: " + deviceId);
  } else {
    Serial.printf("Registration failed. HTTP %d\n", httpCode);
  }
  http.end();
}

// ============================================================
// POST SENSOR DATA
// ============================================================
void postSensorData(float temperature, String status) {
  if (WiFi.status() != WL_CONNECTED) { connectWiFi(); return; }

  HTTPClient http;
  String url = String("http://") + SERVER_IP + ":" + SERVER_PORT + "/api/v1/sensors/data";

  char payload[300];
  snprintf(payload, sizeof(payload),
    "{\"device_id\":\"%s\",\"metrics\":{\"temperature\":%.2f,\"thermal_status\":\"%s\"}}",
    deviceId.c_str(), temperature, status.c_str());

  http.begin(url);
  http.addHeader("Content-Type", "application/json");
  http.addHeader("Authorization", "Bearer " + deviceToken);

  int httpCode = http.POST(payload);
  Serial.printf("[%s] POST status: %d\n", httpCode == 200 ? "OK" : "ERR", httpCode);
  http.end();
}

// ============================================================
// EEPROM
// ============================================================
void saveCredentials() {
  EEPROM.writeString(DEVICE_ID_ADDR, deviceId);
  EEPROM.writeString(TOKEN_ADDR, deviceToken);
  EEPROM.commit();
}
void loadCredentials() {
  deviceId = EEPROM.readString(DEVICE_ID_ADDR);
  deviceToken = EEPROM.readString(TOKEN_ADDR);
  if (deviceId.length() < 10) deviceId = "";
  if (deviceToken.length() < 5) deviceToken = "";
}
