/**
 * RailOS ESP32 Firmware - SW420 Vibration Sensor Node
 * =====================================================
 * Hardware: ESP32 DevKit + SW420 Vibration Sensor
 * 
 * Wiring:
 *   SW420 VCC  → ESP32 3.3V
 *   SW420 GND  → ESP32 GND
 *   SW420 DO   → ESP32 GPIO 34 (Digital Output)
 *   SW420 AO   → ESP32 GPIO 35 (Analog Output - optional, if sensor has AO pin)
 * 
 * Flow:
 *   1. On boot: Connect WiFi → Register device with RailOS Gateway → Get auth token
 *   2. Every 2s: Read vibration → POST to /api/v1/sensors/data with Bearer token
 */

#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <EEPROM.h>

// ============================================================
// CONFIGURATION — Edit these before flashing!
// ============================================================
const char* WIFI_SSID     = "YOUR_WIFI_SSID";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
const char* SERVER_IP     = "192.168.1.X";  // Your PC's local IP (run ipconfig to find it)
const int   SERVER_PORT   = 8000;
const char* TRACK_CODE    = "TR-NDLS-CSMT"; // Which track this sensor is monitoring

// Sensor Pin
const int SW420_DIGITAL_PIN = 34;
const int SW420_ANALOG_PIN  = 35; // Only if your SW420 has AO pin

// EEPROM for storing device credentials across reboots
#define EEPROM_SIZE 512
#define DEVICE_ID_ADDR 0
#define TOKEN_ADDR 100

// ============================================================
// GLOBALS
// ============================================================
String deviceId = "";
String deviceToken = "";
int vibrationCount = 0;
unsigned long lastReportTime = 0;
const unsigned long REPORT_INTERVAL_MS = 2000; // 2 seconds

// ============================================================
// SETUP
// ============================================================
void setup() {
  Serial.begin(115200);
  Serial.println("\n=== RailOS SW420 Vibration Node ===");

  pinMode(SW420_DIGITAL_PIN, INPUT);

  // Initialize EEPROM
  EEPROM.begin(EEPROM_SIZE);

  // Connect to WiFi
  connectWiFi();

  // Load or Register device
  loadCredentials();
  if (deviceId == "" || deviceToken == "") {
    registerDevice();
  } else {
    Serial.println("Loaded saved credentials.");
    Serial.println("Device ID: " + deviceId);
  }
}

// ============================================================
// MAIN LOOP
// ============================================================
void loop() {
  // Count vibration pulses between reporting intervals
  if (digitalRead(SW420_DIGITAL_PIN) == HIGH) {
    vibrationCount++;
    delay(10); // Debounce
  }

  // Report every REPORT_INTERVAL_MS
  if (millis() - lastReportTime >= REPORT_INTERVAL_MS) {
    // Calculate vibration intensity (pulses per second)
    float vibrationIntensity = (float)vibrationCount / (REPORT_INTERVAL_MS / 1000.0);

    // Normalize to 0.0 - 3.0 range (like our ML model expects)
    float vibrationNormalized = min(vibrationIntensity * 0.1f, 3.0f);

    Serial.printf("[SW420] Pulses: %d | Intensity: %.3f\n", vibrationCount, vibrationNormalized);

    // POST to RailOS Gateway
    postSensorData(vibrationNormalized);

    // Reset counter
    vibrationCount = 0;
    lastReportTime = millis();
  }
}

// ============================================================
// WIFI CONNECTION
// ============================================================
void connectWiFi() {
  Serial.printf("Connecting to WiFi: %s\n", WIFI_SSID);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nWiFi connected! IP: " + WiFi.localIP().toString());
}

// ============================================================
// DEVICE REGISTRATION
// ============================================================
void registerDevice() {
  Serial.println("Registering with RailOS Gateway...");

  HTTPClient http;
  String url = String("http://") + SERVER_IP + ":" + SERVER_PORT + "/api/v1/sensors/register";

  // Get MAC address as unique identifier
  String mac = WiFi.macAddress();
  mac.replace(":", "");

  String payload = "{\"mac_address\":\"" + WiFi.macAddress() + 
                   "\",\"type\":\"VIBRATION\",\"name\":\"ESP32-SW420-" + mac.substring(6) + 
                   "\",\"track_code\":\"" + TRACK_CODE + "\"}";

  http.begin(url);
  http.addHeader("Content-Type", "application/json");
  // Registration requires admin token - hardcode the default or use config
  http.addHeader("Authorization", "Bearer ADMIN_JWT_TOKEN_HERE");

  int httpCode = http.POST(payload);
  if (httpCode == 201) {
    String response = http.getString();
    Serial.println("Registered! Response: " + response);

    // Parse JSON response
    StaticJsonDocument<256> doc;
    deserializeJson(doc, response);
    deviceId = doc["device_id"].as<String>();
    deviceToken = doc["token"].as<String>();

    saveCredentials();
    Serial.println("Device ID: " + deviceId);
    Serial.println("Token: " + deviceToken);
  } else {
    Serial.printf("Registration failed. HTTP %d\n", httpCode);
    Serial.println(http.getString());
  }
  http.end();
}

// ============================================================
// POST SENSOR DATA
// ============================================================
void postSensorData(float vibration) {
  if (WiFi.status() != WL_CONNECTED) {
    connectWiFi();
    return;
  }

  HTTPClient http;
  String url = String("http://") + SERVER_IP + ":" + SERVER_PORT + "/api/v1/sensors/data";

  String payload = "{\"device_id\":\"" + deviceId + 
                   "\",\"metrics\":{\"vibration\":" + String(vibration, 4) + "}}";

  http.begin(url);
  http.addHeader("Content-Type", "application/json");
  http.addHeader("Authorization", "Bearer " + deviceToken);

  int httpCode = http.POST(payload);
  if (httpCode == 200) {
    Serial.println("[OK] Data posted to RailOS.");
  } else {
    Serial.printf("[ERR] POST failed. HTTP %d\n", httpCode);
  }
  http.end();
}

// ============================================================
// EEPROM CREDENTIAL STORAGE
// ============================================================
void saveCredentials() {
  EEPROM.writeString(DEVICE_ID_ADDR, deviceId);
  EEPROM.writeString(TOKEN_ADDR, deviceToken);
  EEPROM.commit();
  Serial.println("Credentials saved to EEPROM.");
}

void loadCredentials() {
  deviceId = EEPROM.readString(DEVICE_ID_ADDR);
  deviceToken = EEPROM.readString(TOKEN_ADDR);
  if (deviceId.length() < 10) deviceId = ""; // Invalid, force re-register
  if (deviceToken.length() < 5) deviceToken = "";
}
