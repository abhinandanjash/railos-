"use client";

import { useEffect, useRef } from "react";
import * as THREE from "three";
import { StationData, TrackData, TrainData } from "../services/api";

interface ThreeTwinProps {
  stations: StationData[];
  tracks: TrackData[];
  trains: TrainData[];
}

export default function ThreeTwin({ stations, tracks, trains }: ThreeTwinProps) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    // 1. Setup Scene, Camera, Renderer
    const width = containerRef.current.clientWidth;
    const height = containerRef.current.clientHeight;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x020617); // Slate-950

    // Add glowing ambient and directional light source
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.4);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0x00fff0, 1.2);
    dirLight.position.set(5, 15, 5);
    scene.add(dirLight);

    const camera = new THREE.PerspectiveCamera(60, width / height, 0.1, 1000);
    camera.position.set(0, 15, 20);
    camera.lookAt(0, 0, 0);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    containerRef.current.innerHTML = "";
    containerRef.current.appendChild(renderer.domElement);

    // 2. Add Tactical Grid Helper
    const gridHelper = new THREE.GridHelper(50, 50, 0x00fff0, 0x334155);
    gridHelper.position.y = -1;
    scene.add(gridHelper);

    // Coordinate helpers to scale GPS (Lat/Lon) to Three.js Space
    // New Delhi is ~ (28.6, 77.2), CSMT is ~ (18.9, 72.8)
    // Map bounds NDLS (lat: 28.6, lon: 77.2) -> SBC (lat: 12.9, lon: 77.5) -> HWH (lat: 22.5, lon: 88.3)
    const scaleCoords = (lat: number, lon: number) => {
      const x = (lon - 80.0) * 1.5;
      const z = -(lat - 20.0) * 1.5;
      return new THREE.Vector3(x, 0, z);
    };

    // 3. Render Stations as glowing Cylinders
    const stationMeshes: { [code: string]: THREE.Mesh } = {};
    stations.forEach((s) => {
      const pos = scaleCoords(s.latitude, s.longitude);
      
      const geom = new THREE.CylinderGeometry(0.5, 0.5, 1, 16);
      const mat = new THREE.MeshStandardMaterial({
        color: 0x00fff0,
        emissive: 0x00fff0,
        emissiveIntensity: 0.6,
        roughness: 0.1,
        metalness: 0.8
      });
      const mesh = new THREE.Mesh(geom, mat);
      mesh.position.copy(pos);
      mesh.position.y = 0.5; // sit on grid
      scene.add(mesh);
      stationMeshes[s.code] = mesh;
    });

    // 4. Render Tracks as neon glowing lines
    tracks.forEach((t) => {
      if (!t.start_station || !t.end_station) return;
      const startPos = scaleCoords(t.start_station.lat, t.start_station.lon);
      const endPos = scaleCoords(t.end_station.lat, t.end_station.lon);

      // Color mapping depending on Track safety state
      let color = 0x3b82f6; // blue
      if (t.status === "YELLOW") color = 0xeab308; // warning yellow
      if (t.status === "RED") color = 0xef4444; // critical red
      if (t.status === "EMERGENCY") color = 0xe11d48; // flashing rose

      const points = [startPos, endPos];
      const geom = new THREE.BufferGeometry().setFromPoints(points);
      const mat = new THREE.LineBasicMaterial({
        color: color,
        linewidth: 4 // Note: linewidth parameter is usually neglected by browsers, but color works
      });
      const line = new THREE.Line(geom, mat);
      scene.add(line);
    });

    // 5. Render Trains as animated Orange pyramids
    const trainMeshes: THREE.Mesh[] = [];
    trains.forEach((t) => {
      const pos = scaleCoords(t.latitude, t.longitude);
      
      // Determine train color
      let color = 0xffaa00; // standard operational orange
      if (t.status === "CRITICAL" || t.status === "STOPPED") color = 0xff003c; // alarm red

      const geom = new THREE.ConeGeometry(0.4, 1.2, 4);
      const mat = new THREE.MeshStandardMaterial({
        color: color,
        emissive: color,
        emissiveIntensity: 0.8,
        roughness: 0.2
      });
      const mesh = new THREE.Mesh(geom, mat);
      mesh.position.copy(pos);
      mesh.position.y = 1.0; // float above track
      mesh.rotation.x = Math.PI / 2; // point forward
      scene.add(mesh);
      trainMeshes.push(mesh);
    });

    // 6. Camera Orbit Controls Simulation (Gentle Rotate)
    let angle = 0;
    let isMounted = true;

    const animate = () => {
      if (!isMounted) return;
      requestAnimationFrame(animate);

      // Slow orbital drift
      angle += 0.0015;
      camera.position.x = Math.sin(angle) * 25;
      camera.position.z = Math.cos(angle) * 25;
      camera.lookAt(0, 0, 0);

      renderer.render(scene, camera);
    };

    animate();

    // 7. Handle Resize
    const handleResize = () => {
      if (!containerRef.current) return;
      const w = containerRef.current.clientWidth;
      const h = containerRef.current.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener("resize", handleResize);

    return () => {
      isMounted = false;
      window.removeEventListener("resize", handleResize);
      renderer.dispose();
    };
  }, [stations, tracks, trains]);

  return (
    <div className="relative w-full h-full min-h-[400px] rounded-lg overflow-hidden border border-slate-800">
      <div ref={containerRef} className="w-full h-full" />
      <div className="absolute bottom-3 right-3 bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-md border border-slate-700/50 text-[10px] font-mono text-cyan-400">
        WEBGL TACTICAL TWIN CORE active
      </div>
    </div>
  );
}
