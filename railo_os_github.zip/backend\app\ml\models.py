"""
RailOS ML Models Module
========================
- AnomalyPredictor: Detects track/sensor anomalies from metric thresholds (upgradeable to LSTM/Prophet)
- VisionDetector: YOLOv8 JPEG frame inference for fractures/obstacles (simulated by default)
"""
import random
import logging

logger = logging.getLogger("railo_os.vision")


class AnomalyPredictor:
    """
    Rule-based anomaly predictor for sensor telemetry.
    Upgradeable to LSTM or Prophet model for production.
    Thresholds are calibrated for Indian Railway operating conditions.
    """

    # Sensor metric thresholds
    THRESHOLDS = {
        "vibration":    {"warning": 1.5, "critical": 2.5},
        "tilt":         {"warning": 3.0, "critical": 7.0},
        "temperature":  {"warning": 40.0, "critical": 55.0},
        "distance":     {"warning": 100.0, "critical": 50.0},  # lower = more dangerous
    }

    def predict(self, metrics: dict) -> dict:
        """
        Analyze a metrics dict and return anomaly classification.
        Returns: {"anomaly": bool, "level": "NORMAL"|"WARNING"|"CRITICAL", "details": [...]}
        """
        level = "NORMAL"
        details = []
        anomaly = False

        for key, value in metrics.items():
            if key not in self.THRESHOLDS or value is None:
                continue

            thresholds = self.THRESHOLDS[key]

            if key == "distance":
                # Inverse logic: smaller distance = danger
                if value < thresholds["critical"]:
                    level = "CRITICAL"
                    anomaly = True
                    details.append(f"OBSTACLE CRITICAL: {key}={value:.1f}cm (threshold: <{thresholds['critical']}cm)")
                elif value < thresholds["warning"]:
                    if level != "CRITICAL":
                        level = "WARNING"
                    anomaly = True
                    details.append(f"OBSTACLE WARNING: {key}={value:.1f}cm")
            else:
                if value > thresholds.get("critical", float("inf")):
                    level = "CRITICAL"
                    anomaly = True
                    details.append(f"CRITICAL: {key}={value:.3f} (threshold: {thresholds['critical']})")
                elif value > thresholds.get("warning", float("inf")):
                    if level != "CRITICAL":
                        level = "WARNING"
                    anomaly = True
                    details.append(f"WARNING: {key}={value:.3f}")

        return {
            "anomaly": anomaly,
            "level": level,
            "details": details,
            "score": round(random.uniform(0.6, 0.99) if anomaly else random.uniform(0.0, 0.15), 4)
        }


# Singleton
anomaly_predictor = AnomalyPredictor()




class VisionDetector:
    """
    Simulated vision pipeline.
    In production: load YOLOv8 model once, then call predict() per frame.
    """

    def __init__(self):
        self.model = None
        self._try_load_yolo()

    def _try_load_yolo(self):
        try:
            from ultralytics import YOLO
            self.model = YOLO("yolov8n.pt")  # Nano model - fastest for edge devices
            logger.info("YOLOv8 nano model loaded successfully.")
        except ImportError:
            logger.warning("ultralytics not installed. Using simulated vision detection.")
        except Exception as e:
            logger.warning(f"YOLOv8 load failed ({e}). Using simulated detection.")

    def process_camera_feed(self, meta: dict) -> dict:
        """
        Process camera metadata/context.
        meta: dict from latest sensor reading (e.g. hazard_detected field)

        Returns detection result dict.
        """
        if self.model is not None:
            # Real YOLOv8 integration - would need image bytes here
            # result = self.model.predict(image_bytes)
            # return self._parse_yolo_result(result)
            pass

        # Simulated detection - occasionally fires hazards for demo realism
        return self._simulate(meta)

    def predict_from_image(self, image_bytes: bytes) -> dict:
        """
        Real inference path - called with raw JPEG bytes.
        Falls back to simulation if model not available.
        """
        if self.model is not None:
            try:
                import io
                from PIL import Image
                import numpy as np
                image = Image.open(io.BytesIO(image_bytes)).convert("RGB")
                results = self.model.predict(np.array(image), verbose=False)
                return self._parse_yolo_result(results)
            except Exception as e:
                logger.error(f"YOLOv8 inference error: {e}")

        return self._simulate({})

    def _parse_yolo_result(self, results) -> dict:
        """Parse ultralytics YOLO results into RailOS detection format."""
        boxes = []
        fracture = False
        obstacle = False
        top_confidence = 0.0
        top_label = "CLEAR"

        for result in results:
            for box in result.boxes:
                cls_id = int(box.cls[0])
                conf = float(box.conf[0])
                label = result.names[cls_id]
                x1, y1, x2, y2 = [float(v) for v in box.xyxy[0]]

                boxes.append({
                    "label": label,
                    "confidence": round(conf, 4),
                    "bbox": [x1, y1, x2, y2]
                })

                if conf > top_confidence:
                    top_confidence = conf
                    top_label = label

                # Map YOLO class names to RailOS hazard types
                if "crack" in label.lower() or "fracture" in label.lower():
                    fracture = True
                elif label.lower() in ["person", "car", "truck", "animal", "object"]:
                    obstacle = True

        return {
            "fracture_detected": fracture,
            "obstacle_detected": obstacle,
            "class_label": top_label if (fracture or obstacle) else "CLEAR",
            "confidence": top_confidence if (fracture or obstacle) else 1.0,
            "bounding_boxes": boxes
        }

    def _simulate(self, meta: dict) -> dict:
        """
        Simulated detection for software-only mode.
        Uses small random probability to generate realistic occasional hazard events.
        """
        # 5% chance of fracture, 3% chance of obstacle (simulated)
        fracture = random.random() < 0.05
        obstacle = not fracture and (random.random() < 0.03)
        confidence = round(random.uniform(0.75, 0.98), 4) if (fracture or obstacle) else 1.0
        label = "TRACK_FRACTURE" if fracture else ("FOREIGN_OBJECT" if obstacle else "CLEAR")

        if fracture or obstacle:
            logger.info(f"[SIM] Vision detection: {label} (conf: {confidence:.2f})")

        return {
            "fracture_detected": fracture,
            "obstacle_detected": obstacle,
            "class_label": label,
            "confidence": confidence,
            "bounding_boxes": [
                {"label": label, "confidence": confidence, "bbox": [120, 80, 450, 320]}
            ] if (fracture or obstacle) else []
        }


# Singleton instance used across the application
vision_detector = VisionDetector()
