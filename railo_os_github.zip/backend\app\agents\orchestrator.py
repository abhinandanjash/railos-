import logging
from uuid import UUID, uuid4
from datetime import datetime
from sqlmodel import Session, select
from app.db.session import engine
from app.models.schemas import Track, Incident, Train
from app.agents.safety_agent import safety_agent
from app.agents.emergency_agent import emergency_agent

logger = logging.getLogger("railo_os.orchestrator")

class AgentOrchestrator:
    @staticmethod
    def run_safety_loop():
        """Periodically evaluates all track spans and handles critical thresholds."""
        with Session(engine) as session:
            tracks = session.exec(select(Track)).all()
            for track in tracks:
                # 1. Run Safety Agent ML evaluation on track sensors
                analysis = safety_agent.analyze_track_health(session, track.id)
                risk_score = analysis.get("risk_score", 0.0)

                # 2. Check if risk is critical (> 75)
                if risk_score >= 75:
                    # Check if there's already an active open incident for this track
                    existing_incident = session.exec(
                        select(Incident)
                        .where(Incident.track_id == track.id)
                        .where(Incident.status != "RESOLVED")
                    ).first()

                    if not existing_incident:
                        logger.warning(f"CRITICAL RISK IDENTIFIED ON TRACK: {track.code} (Score: {risk_score})")
                        
                        # Find any train currently on this track to associate with incident
                        train_on_track = session.exec(
                            select(Train).where(Train.current_track_id == track.id)
                        ).first()

                        # Determine type based on explanation keyword
                        explanation = analysis.get("explanation", "").upper()
                        incident_type = "TRACK_FRACTURE"
                        if "OBSTACLE" in explanation or "FOREIGN" in explanation:
                            incident_type = "OBSTACLE_DETECTED"
                        elif "FLOOD" in explanation:
                            incident_type = "FLOODING"

                        # Create new Incident
                        new_incident = Incident(
                            code=f"INC-{datetime.utcnow().strftime('%Y%m%d%H%M')}-{track.code[-4:]}",
                            type=incident_type,
                            severity="CRITICAL",
                            train_id=train_on_track.id if train_on_track else None,
                            track_id=track.id,
                            status="OPEN",
                            description=analysis.get("explanation", "Sensor telemetry anomaly detected.")
                        )
                        session.add(new_incident)
                        session.commit()
                        session.refresh(new_incident)

                        # 3. Hand off to Emergency Agent to handle containment plan
                        logger.info(f"Handing off to Emergency Coordinator for incident: {new_incident.code}")
                        emergency_agent.handle_incident(session, new_incident.id)

agent_orchestrator = AgentOrchestrator()
