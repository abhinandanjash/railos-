import os
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    HOST: str = "0.0.0.0"
    PORT: int = 8000
    DEBUG: bool = True
    JWT_SECRET: str = "8f45a72db634a36e9ff98a183578eeef727289f81a70c3c86b24e60802c0199e"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 1440

    POSTGRES_USER: str = "postgres"
    POSTGRES_PASSWORD: str = "postgres"
    POSTGRES_DB: str = "railo_os"
    POSTGRES_HOST: str = "localhost"
    POSTGRES_PORT: int = 5432
    
    @property
    def DATABASE_URL(self) -> str:
        # Dynamically build based on environment context (local dev vs docker)
        host = os.getenv("POSTGRES_HOST", self.POSTGRES_HOST)
        return f"postgresql://{self.POSTGRES_USER}:{self.POSTGRES_PASSWORD}@{host}:{self.POSTGRES_PORT}/{self.POSTGRES_DB}"

    REDIS_URL: str = "redis://localhost:6379/0"

    NEO4J_URI: str = "bolt://localhost:7687"
    NEO4J_USER: str = "neo4j"
    NEO4J_PASSWORD: str = "password"

    SIMULATION_SPEED: float = 1.0
    FRACTURE_PROBABILITY: float = 0.05
    OBSTACLE_PROBABILITY: float = 0.05
    FLOOD_PROBABILITY: float = 0.03

    vibration_normal_mean: float = 0.2
    vibration_normal_std: float = 0.05
    vibration_anomaly_mean: float = 1.5
    vibration_anomaly_std: float = 0.3
    tilt_normal_mean: float = 0.1
    tilt_normal_std: float = 0.02
    tilt_anomaly_mean: float = 2.5
    tilt_anomaly_std: float = 0.5
    temperature_normal_mean: float = 25.0
    temperature_normal_std: float = 2.0
    temperature_anomaly_mean: float = 55.0
    temperature_anomaly_std: float = 5.0

    class Config:
        env_file = ".env"
        extra = "allow"

settings = Settings()
